# Producer of FHIR resources - JSON Representation - DK MedCom Notes v1.0.0-trial-use

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Producer of FHIR resources**

## : Producer of FHIR resources - JSON Representation

| |
| :--- |
| Active as of 2026-03-10 |

[Raw json](ActorDefinition-ProducerActor.json) | [Download](ActorDefinition-ProducerActor.json)

