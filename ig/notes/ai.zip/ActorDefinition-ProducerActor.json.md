# Producer of FHIR resources - JSON Representation - DK MedCom Notes v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Producer of FHIR resources**

## : Producer of FHIR resources - JSON Representation

| |
| :--- |
| Active as of 2026-05-13 |

[Raw json](ActorDefinition-ProducerActor.json) | [Download](ActorDefinition-ProducerActor.json)

