# medcom.fhir.dk.notes#1.0.0: DK MedCom Notes

## Pages

* [Home](index.md)
* [Examples](examples.md)
* [Producer of FHIR resources - JSON Representation](ActorDefinition-ProducerActor.json.md)
* [Producer of FHIR resources - Testing](ActorDefinition-ProducerActor-testing.md)
* [Producer of FHIR resources](ActorDefinition-ProducerActor.md)
* [Artifacts Summary](artifacts.md)
* [Dependencies](dependencies.md)
* [Extensions](extensions.md)
* [Downloads](downloads.md)
* [Profiles](profiles.md)
* [](ActorDefinition-ProducerActor.change.history.md)
* [Producer of FHIR resources - TTL Representation](ActorDefinition-ProducerActor.ttl.md)
* [Producer of FHIR resources - XML Representation](ActorDefinition-ProducerActor.xml.md)

## Resources

### Resource Profiles

* [MedComNotesBundle](StructureDefinition-medcom-notes-bundle.md)
* [MedComNotesComposition](StructureDefinition-medcom-notes-composition.md)
* [MedComNotesObservation](StructureDefinition-medcom-notes-observation.md)

### ImplementationGuides

* [DK MedCom Notes](index.md)

### Examples

* [ProducerActor (Basic)](Basic-ProducerActor.md)
* [9521a7f0-bad4-4a46-8c51-cd8378b24106 (Bundle)](Bundle-9521a7f0-bad4-4a46-8c51-cd8378b24106.md)
* [ba7d908a-0134-4f28-b5f5-0fcaf088e60b (Bundle)](Bundle-ba7d908a-0134-4f28-b5f5-0fcaf088e60b.md)
* [Journalnotat for 3001749995 (Composition)](Composition-43fe2ddc-fd31-443b-bef0-e29c030d6572.md)
* [Journalnotat for 3001749995 (Composition)](Composition-cff723a9-fae7-4fc6-8db2-6e49cbbc928a.md)
* [d2c9d517-3abd-450e-a3c2-18f18da6fd88 (Observation)](Observation-d2c9d517-3abd-450e-a3c2-18f18da6fd88.md)
* [if810168-ee7c-4f34-8012-9aff6c1d86e7 (Observation)](Observation-if810168-ee7c-4f34-8012-9aff6c1d86e7.md)
* [Lægerne Hasseris Bymidte (Organization)](Organization-b3860fb8-4b1d-4be5-8290-e6a026d10555.md)
* [Lægerne Hasseris Bymidte (Organization)](Organization-f8d0eb07-5336-4005-9081-b065f9a82663.md)
* [b3b07166-24d7-462b-acb3-1a29269c4740 (Patient)](Patient-b3b07166-24d7-462b-acb3-1a29269c4740.md)
* [d65cd8db-4520-4264-87be-a5fd01fb9762 (Patient)](Patient-d65cd8db-4520-4264-87be-a5fd01fb9762.md)
* [48ed6310-3095-44da-9e34-d1cd6bd830c9 (Practitioner)](Practitioner-48ed6310-3095-44da-9e34-d1cd6bd830c9.md)
* [bb6fa4e1-f8b1-4bf4-b77e-bb03b2cc9820 (PractitionerRole)](PractitionerRole-bb6fa4e1-f8b1-4bf4-b77e-bb03b2cc9820.md)
