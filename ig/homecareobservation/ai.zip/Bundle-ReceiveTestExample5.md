# ReceiveTestExample5 - MedCom HomeCareObservation v1.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ReceiveTestExample5**

## Example Bundle: ReceiveTestExample5



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "ReceiveTestExample5",
  "meta" : {
    "profile" : [
      "http://medcomfhir.dk/ig/homecareobservation/StructureDefinition/medcom-homecareobservation-message"
    ]
  },
  "type" : "message",
  "timestamp" : "2026-04-07T15:00:00+02:00",
  "entry" : [
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/MessageHeader/ReceiveTestExample5-MessageHeader",
      "resource" : {
        "resourceType" : "MessageHeader",
        "id" : "ReceiveTestExample5-MessageHeader",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/homecareobservation/StructureDefinition/medcom-homecareobservation-messageheader"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_ReceiveTestExample5-MessageHeader\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader ReceiveTestExample5-MessageHeader</b></p><a name=\"ReceiveTestExample5-MessageHeader\"> </a><a name=\"hcReceiveTestExample5-MessageHeader\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-homecareobservation-messageheader.html\">MedComHomeCareObservationMessageHeader</a></p></div><p><b>event</b>: <a href=\"http://medcomfhir.dk/ig/terminology/2.0.2/CodeSystem-medcom-messaging-eventCodes.html#medcom-messaging-eventCodes-homecareobservation-message\">MedComMessagingEventCodes: homecareobservation-message</a> (HomeCare Observation Message)</p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Endpoint</b></td><td><b>Receiver</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><a href=\"https://sor2.sum.dsdn.dk/#id=73091000016008\">https://sor2.sum.dsdn.dk/#id=73091000016008</a></td><td><a href=\"Bundle-ReceiveTestExample1.html#Organization_AgerskovsLaegePraksisRequesterOrgKnownDr\">Organization Agerskov lægepraksis</a></td></tr></table><p><b>sender</b>: <a href=\"Bundle-ReceiveTestExample1.html#Organization_SkovlyAktivitetstilbudProducerOrg\">Organization Pleje og Rehabilitering</a></p><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://sor2.sum.dsdn.dk/#id=1267041000016006\">https://sor2.sum.dsdn.dk/#id=1267041000016006</a></td></tr></table><p><b>focus</b>: <a href=\"Bundle-ReceiveTestExample5.html#DiagnosticReport_ReceiveTestExample5-DiagnosticReport\">Diagnostic Report for 'HomeCareDiagnosticReport' for '-&gt;Bruno Test Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)'</a></p><p><b>definition</b>: <a href=\"http://medcomfhir.dk/ig/messagedefinitions/1.0.1-trial-use/MessageDefinition-MedComHomeCareObservationMessageDefinitionV1.1.html\">http://medcomfhir.dk/ig/messagedefinitions/MessageDefinition/MedComHomeCareObservationMessageDefinition|1.1</a></p></div>"
        },
        "eventCoding" : {
          "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-eventCodes",
          "code" : "homecareobservation-message"
        },
        "destination" : [
          {
            "extension" : [
              {
                "url" : "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-destinationUseExtension",
                "valueCoding" : {
                  "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-destinationUse",
                  "code" : "primary"
                }
              }
            ],
            "endpoint" : "https://sor2.sum.dsdn.dk/#id=73091000016008",
            "receiver" : {
              "reference" : "Organization/AgerskovsLaegePraksisRequesterOrgKnownDr"
            }
          }
        ],
        "sender" : {
          "reference" : "Organization/SkovlyAktivitetstilbudProducerOrg"
        },
        "source" : {
          "endpoint" : "https://sor2.sum.dsdn.dk/#id=1267041000016006"
        },
        "focus" : [
          {
            "reference" : "DiagnosticReport/ReceiveTestExample5-DiagnosticReport"
          }
        ],
        "definition" : "http://medcomfhir.dk/ig/messagedefinitions/MessageDefinition/MedComHomeCareObservationMessageDefinition|1.1"
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Patient/BrunoTestElmerPatient",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "BrunoTestElmerPatient",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_BrunoTestElmerPatient\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient BrunoTestElmerPatient</b></p><a name=\"BrunoTestElmerPatient\"> </a><a name=\"hcBrunoTestElmerPatient\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/2.4.0/StructureDefinition-medcom-core-patient.html\">MedComCorePatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Bruno Test Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</p><hr/></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:1.2.208.176.1.2",
            "value" : "2509479989"
          }
        ],
        "name" : [
          {
            "use" : "official",
            "family" : "Elmer",
            "given" : ["Bruno Test"]
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/DiagnosticReport/ReceiveTestExample5-DiagnosticReport",
      "resource" : {
        "resourceType" : "DiagnosticReport",
        "id" : "ReceiveTestExample5-DiagnosticReport",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/homecareobservation/StructureDefinition/medcom-homecareobservation-diagnosticreport"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DiagnosticReport_ReceiveTestExample5-DiagnosticReport\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DiagnosticReport ReceiveTestExample5-DiagnosticReport</b></p><a name=\"ReceiveTestExample5-DiagnosticReport\"> </a><a name=\"hcReceiveTestExample5-DiagnosticReport\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-homecareobservation-diagnosticreport.html\">MedComHomeCareObservationDiagnosticReport</a></p></div><h2><span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/MedComDiagnosticReportCodes HomeCareReport}\">HomeCareDiagnosticReport</span> </h2><table class=\"grid\"><tr><td>Subject</td><td>Bruno Test Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</td></tr><tr><td>Reported</td><td>2026-04-07 15:00:00+0200</td></tr><tr><td>Performers</td><td> <a href=\"Bundle-ReceiveTestExample1.html#Organization_SkovlyAktivitetstilbudProducerOrg\">Organization Pleje og Rehabilitering</a> <a href=\"Bundle-ReceiveTestExample5.html#PractitionerRole_OdaOverNursePractitionerRole\">PractitionerRole </a></td></tr></table><p><b>Report Details</b></p><table class=\"grid\"><tr><td><b>Code</b></td><td><b>Value</b></td><td><b>Flags</b></td><td><b>Note</b></td><td><b>When For</b></td></tr><tr><td><a href=\"Bundle-ReceiveTestExample5.html#Observation_GlucoseObservationOnBrunoWrongNPU\"><span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU2026}\">P; Invalid Code</span></a></td><td>6.8 mmol/L</td><td>Final, <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></td><td/><td>2025-08-07 14:47:23+0200</td></tr><tr><td><a href=\"Bundle-ReceiveTestExample5.html#Observation_CReaktiveProteinObservationOnBrunoNoValue\"><span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU19748}\">P—C-reaktivt protein; massek. = ? mg/L</span></a></td><td/><td>Final, <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></td><td><blockquote><div><p>Denne observation er dateret til efter det kommunale prøvesvar er genereret.</p>\n</div></blockquote></td><td>2025-08-09 13:47:23+0200</td></tr></table></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/MedComDiagnosticReportCodes",
              "code" : "HomeCareReport"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/BrunoTestElmerPatient"
        },
        "issued" : "2026-04-07T15:00:00+02:00",
        "performer" : [
          {
            "reference" : "Organization/SkovlyAktivitetstilbudProducerOrg"
          },
          {
            "reference" : "PractitionerRole/OdaOverNursePractitionerRole"
          }
        ],
        "result" : [
          {
            "reference" : "Observation/GlucoseObservationOnBrunoWrongNPU"
          },
          {
            "reference" : "Observation/CReaktiveProteinObservationOnBrunoNoValue"
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/PractitionerRole/OdaOverNursePractitionerRole",
      "resource" : {
        "resourceType" : "PractitionerRole",
        "id" : "OdaOverNursePractitionerRole",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-practitionerrole"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_OdaOverNursePractitionerRole\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole OdaOverNursePractitionerRole</b></p><a name=\"OdaOverNursePractitionerRole\"> </a><a name=\"hcOdaOverNursePractitionerRole\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/2.4.0/StructureDefinition-medcom-core-practitionerrole.html\">MedComCorePractitionerRole</a></p></div><p><b>practitioner</b>: <a href=\"Bundle-ReceiveTestExample5.html#Practitioner_OdaOverNurse\">Practitioner Oda Over Pedersen </a></p><p><b>code</b>: <span title=\"Codes:\">Oversygeplejerske</span></p></div>"
        },
        "practitioner" : {
          "reference" : "Practitioner/OdaOverNurse"
        },
        "code" : [
          {
            "text" : "Oversygeplejerske"
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Practitioner/OdaOverNurse",
      "resource" : {
        "resourceType" : "Practitioner",
        "id" : "OdaOverNurse",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-practitioner"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_OdaOverNurse\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner OdaOverNurse</b></p><a name=\"OdaOverNurse\"> </a><a name=\"hcOdaOverNurse\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/2.4.0/StructureDefinition-medcom-core-practitioner.html\">MedComCorePractitioner</a></p></div><p><b>name</b>: Oda Over Pedersen </p><p><b>telecom</b>: <a href=\"tel:+4505577668\">+45 05577668</a></p></div>"
        },
        "name" : [
          {
            "family" : "Pedersen",
            "given" : ["Oda", "Over"]
          }
        ],
        "telecom" : [
          {
            "system" : "phone",
            "value" : "+45 05577668"
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Organization/AgerskovsLaegePraksisRequesterOrgKnownDr",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "AgerskovsLaegePraksisRequesterOrgKnownDr",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-requesterorganization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_AgerskovsLaegePraksisRequesterOrgKnownDr\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization AgerskovsLaegePraksisRequesterOrgKnownDr</b></p><a name=\"AgerskovsLaegePraksisRequesterOrgKnownDr\"> </a><a name=\"hcAgerskovsLaegePraksisRequesterOrgKnownDr\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/3.0.0/StructureDefinition-medcom-requesterorganization.html\">MedComMessagingRequesterOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790000147465, <code>urn:oid:1.2.208.176.1.1</code>/73091000016008, <code>urn:oid:1.2.208.176.1.4</code>/045861</p><p><b>name</b>: Agerskov lægepraksis</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td></tr><tr><td style=\"display: none\">*</td><td>Some Doctor at Agerskov(Official)</td></tr></table></div>"
        },
        "identifier" : [
          {
            "system" : "https://www.gs1.org/gln",
            "value" : "5790000147465"
          },
          {
            "system" : "urn:oid:1.2.208.176.1.1",
            "value" : "73091000016008"
          },
          {
            "system" : "urn:oid:1.2.208.176.1.4",
            "value" : "045861"
          }
        ],
        "name" : "Agerskov lægepraksis",
        "contact" : [
          {
            "name" : {
              "use" : "official",
              "text" : "Some Doctor at Agerskov",
              "family" : "Andersen",
              "given" : ["SDaA"]
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Organization/SkovlyAktivitetstilbudProducerOrg",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "SkovlyAktivitetstilbudProducerOrg",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-producer-organization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_SkovlyAktivitetstilbudProducerOrg\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization SkovlyAktivitetstilbudProducerOrg</b></p><a name=\"SkovlyAktivitetstilbudProducerOrg\"> </a><a name=\"hcSkovlyAktivitetstilbudProducerOrg\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/3.0.0/StructureDefinition-medcom-producer-organization.html\">MedComCoreProducerOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790002757778, <code>urn:oid:1.2.208.176.1.1</code>/1267041000016006, <code>http://medcomfhir.dk/ig/terminology/CodeSystem/MedComProducentID</code>/KAF</p><p><b>name</b>: Pleje og Rehabilitering</p></div>"
        },
        "identifier" : [
          {
            "system" : "https://www.gs1.org/gln",
            "value" : "5790002757778"
          },
          {
            "system" : "urn:oid:1.2.208.176.1.1",
            "value" : "1267041000016006"
          },
          {
            "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/MedComProducentID",
            "value" : "KAF"
          }
        ],
        "name" : "Pleje og Rehabilitering"
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Provenance/ReceiveTestExample5-Provenance",
      "resource" : {
        "resourceType" : "Provenance",
        "id" : "ReceiveTestExample5-Provenance",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-provenance"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_ReceiveTestExample5-Provenance\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance ReceiveTestExample5-Provenance</b></p><a name=\"ReceiveTestExample5-Provenance\"> </a><a name=\"hcReceiveTestExample5-Provenance\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/3.0.0/StructureDefinition-medcom-messaging-provenance.html\">MedComMessagingProvenance</a></p></div><p>Provenance for <a href=\"Bundle-ReceiveTestExample5.html#MessageHeader_ReceiveTestExample5-MessageHeader\">MessageHeader: event[x] = HomeCare Observation Message (MedComMessagingEventCodes#homecareobservation-message); definition = http://medcomfhir.dk/ig/messagedefinitions/MessageDefinition/MedComHomeCareObservationMessageDefinition|1.1</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>2026-04-07 15:00:00+0200</td></tr><tr><td>Recorded</td><td>2026-04-07 15:00:00+0200</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes new-message}\">A new message has been sent</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>who</b></td></tr><tr><td><a href=\"Bundle-ReceiveTestExample1.html#Organization_SkovlyAktivitetstilbudProducerOrg\">Organization Pleje og Rehabilitering</a></td></tr></table></div>"
        },
        "target" : [
          {
            "reference" : "MessageHeader/ReceiveTestExample5-MessageHeader"
          }
        ],
        "occurredDateTime" : "2026-04-07T15:00:00+02:00",
        "recorded" : "2026-04-07T15:00:00+02:00",
        "activity" : {
          "coding" : [
            {
              "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes",
              "code" : "new-message"
            }
          ]
        },
        "agent" : [
          {
            "who" : {
              "reference" : "Organization/SkovlyAktivitetstilbudProducerOrg"
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Observation/GlucoseObservationOnBrunoWrongNPU",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "GlucoseObservationOnBrunoWrongNPU",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/homecareobservation/StructureDefinition/medcom-homecare-observation"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_GlucoseObservationOnBrunoWrongNPU\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation GlucoseObservationOnBrunoWrongNPU</b></p><a name=\"GlucoseObservationOnBrunoWrongNPU\"> </a><a name=\"hcGlucoseObservationOnBrunoWrongNPU\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-homecare-observation.html\">MedComHomeCareObservation</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU2026}\">P; Invalid Code</span></p><p><b>subject</b>: <a href=\"Bundle-ReceiveTestExample5.html#Patient_BrunoTestElmerPatient\">Bruno Test Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</a></p><p><b>effective</b>: 2025-08-07 14:47:23+0200</p><p><b>value</b>: 6.8 mmol/L</p><p><b>interpretation</b>: <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "urn:oid:1.2.208.176.2.1",
              "code" : "NPU2026",
              "display" : "P; Invalid Code"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/BrunoTestElmerPatient"
        },
        "effectiveDateTime" : "2025-08-07T14:47:23+02:00",
        "valueQuantity" : {
          "value" : 6.8,
          "unit" : "mmol/L"
        },
        "interpretation" : [
          {
            "coding" : [
              {
                "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes",
                "code" : "NI",
                "display" : "Not Interpreted"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Observation/CReaktiveProteinObservationOnBrunoNoValue",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "CReaktiveProteinObservationOnBrunoNoValue",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/homecareobservation/StructureDefinition/medcom-homecare-observation"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_CReaktiveProteinObservationOnBrunoNoValue\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation CReaktiveProteinObservationOnBrunoNoValue</b></p><a name=\"CReaktiveProteinObservationOnBrunoNoValue\"> </a><a name=\"hcCReaktiveProteinObservationOnBrunoNoValue\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-homecare-observation.html\">MedComHomeCareObservation</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU19748}\">P—C-reaktivt protein; massek. = ? mg/L</span></p><p><b>subject</b>: <a href=\"Bundle-ReceiveTestExample5.html#Patient_BrunoTestElmerPatient\">Bruno Test Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</a></p><p><b>effective</b>: 2025-08-09 13:47:23+0200</p><p><b>interpretation</b>: <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></p><p><b>note</b>: </p><blockquote><div><p>Denne observation er dateret til efter det kommunale prøvesvar er genereret.</p>\n</div></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "urn:oid:1.2.208.176.2.1",
              "code" : "NPU19748",
              "display" : "P—C-reaktivt protein; massek. = ? mg/L"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/BrunoTestElmerPatient"
        },
        "effectiveDateTime" : "2025-08-09T13:47:23+02:00",
        "interpretation" : [
          {
            "coding" : [
              {
                "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes",
                "code" : "NI",
                "display" : "Not Interpreted"
              }
            ]
          }
        ],
        "note" : [
          {
            "text" : "Denne observation er dateret til efter det kommunale prøvesvar er genereret."
          }
        ]
      }
    }
  ]
}

```
