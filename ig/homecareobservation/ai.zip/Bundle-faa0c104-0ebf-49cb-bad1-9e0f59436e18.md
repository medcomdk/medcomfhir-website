# HomeCareObservation message-Urine dipsticks and subject refused consent. - MedCom HomeCareObservation v1.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HomeCareObservation message-Urine dipsticks and subject refused consent.**

## Example Bundle: HomeCareObservation message-Urine dipsticks and subject refused consent.



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "faa0c104-0ebf-49cb-bad1-9e0f59436e18",
  "meta" : {
    "profile" : [
      "http://medcomfhir.dk/ig/homecareobservation/StructureDefinition/medcom-homecareobservation-message"
    ]
  },
  "type" : "message",
  "timestamp" : "2023-09-13T12:24:09+02:00",
  "entry" : [
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/MessageHeader/e9f4cc68-b1b7-46b2-ba74-7cc39a914bfa",
      "resource" : {
        "resourceType" : "MessageHeader",
        "id" : "e9f4cc68-b1b7-46b2-ba74-7cc39a914bfa",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/homecareobservation/StructureDefinition/medcom-homecareobservation-messageheader"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_e9f4cc68-b1b7-46b2-ba74-7cc39a914bfa\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader e9f4cc68-b1b7-46b2-ba74-7cc39a914bfa</b></p><a name=\"e9f4cc68-b1b7-46b2-ba74-7cc39a914bfa\"> </a><a name=\"hce9f4cc68-b1b7-46b2-ba74-7cc39a914bfa\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-homecareobservation-messageheader.html\">MedComHomeCareObservationMessageHeader</a></p></div><p><b>event</b>: <a href=\"http://medcomfhir.dk/ig/terminology/2.0.2/CodeSystem-medcom-messaging-eventCodes.html#medcom-messaging-eventCodes-homecareobservation-message\">MedComMessagingEventCodes: homecareobservation-message</a> (HomeCare Observation Message)</p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Endpoint</b></td><td><b>Receiver</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><a href=\"https://sor2.sum.dsdn.dk/#id=52581000016005\">https://sor2.sum.dsdn.dk/#id=52581000016005</a></td><td><a href=\"Organization-d1c1fa90-2c7e-4dd7-b2e8-e40281635a98.html\">Organization Skødstrup Lægepraksis</a></td></tr></table><p><b>sender</b>: <a href=\"Organization-72cc3a2c-1dda-4b95-b50a-0f7ac19640f4.html\">Organization Pleje og Rehabilitering</a></p><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://sor2.sum.dsdn.dk/#id=1144561000016002\">https://sor2.sum.dsdn.dk/#id=1144561000016002</a></td></tr></table><p><b>focus</b>: <a href=\"DiagnosticReport-6d08f000-33cc-41f3-a7c2-c086d53d31a7.html\">Diagnostic Report for 'HomeCareDiagnosticReport' for '-&gt;Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)'</a></p><p><b>definition</b>: <a href=\"http://medcomfhir.dk/ig/messagedefinitions/1.0.1-trial-use/MessageDefinition-MedComHomeCareObservationMessageDefinitionV1.1.html\">http://medcomfhir.dk/ig/messagedefinitions/MessageDefinition/MedComHomeCareObservationMessageDefinition|1.1</a></p></div>"
        },
        "eventCoding" : {
          "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-eventCodes",
          "code" : "homecareobservation-message"
        },
        "destination" : [
          {
            "extension" : [
              {
                "url" : "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-destinationUseExtension",
                "valueCoding" : {
                  "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-destinationUse",
                  "code" : "primary"
                }
              }
            ],
            "endpoint" : "https://sor2.sum.dsdn.dk/#id=52581000016005",
            "receiver" : {
              "reference" : "Organization/d1c1fa90-2c7e-4dd7-b2e8-e40281635a98"
            }
          }
        ],
        "sender" : {
          "reference" : "Organization/72cc3a2c-1dda-4b95-b50a-0f7ac19640f4"
        },
        "source" : {
          "endpoint" : "https://sor2.sum.dsdn.dk/#id=1144561000016002"
        },
        "focus" : [
          {
            "reference" : "DiagnosticReport/6d08f000-33cc-41f3-a7c2-c086d53d31a7"
          }
        ],
        "definition" : "http://medcomfhir.dk/ig/messagedefinitions/MessageDefinition/MedComHomeCareObservationMessageDefinition|1.1"
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Patient/733cef33-3626-422b-955d-d506aaa65fe1",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "733cef33-3626-422b-955d-d506aaa65fe1",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_733cef33-3626-422b-955d-d506aaa65fe1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient 733cef33-3626-422b-955d-d506aaa65fe1</b></p><a name=\"733cef33-3626-422b-955d-d506aaa65fe1\"> </a><a name=\"hc733cef33-3626-422b-955d-d506aaa65fe1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/2.4.0/StructureDefinition-medcom-core-patient.html\">MedComCorePatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</p><hr/></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:1.2.208.176.1.2",
            "value" : "2509479989"
          }
        ],
        "name" : [
          {
            "use" : "official",
            "family" : "Elmer"
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/DiagnosticReport/6d08f000-33cc-41f3-a7c2-c086d53d31a7",
      "resource" : {
        "resourceType" : "DiagnosticReport",
        "id" : "6d08f000-33cc-41f3-a7c2-c086d53d31a7",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/homecareobservation/StructureDefinition/medcom-homecareobservation-diagnosticreport"
          ],
          "security" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v3-Confidentiality",
              "code" : "R",
              "display" : "Restricted"
            }
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DiagnosticReport_6d08f000-33cc-41f3-a7c2-c086d53d31a7\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DiagnosticReport 6d08f000-33cc-41f3-a7c2-c086d53d31a7</b></p><a name=\"6d08f000-33cc-41f3-a7c2-c086d53d31a7\"> </a><a name=\"hc6d08f000-33cc-41f3-a7c2-c086d53d31a7\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-homecareobservation-diagnosticreport.html\">MedComHomeCareObservationDiagnosticReport</a></p><p style=\"margin-bottom: 0px\">Security Label: Restricted (Details: Confidentiality code R = 'Restricted')</p></div><h2><span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/MedComDiagnosticReportCodes HomeCareReport}\">HomeCareDiagnosticReport</span> </h2><table class=\"grid\"><tr><td>Subject</td><td>Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</td></tr><tr><td>Reported</td><td>2023-09-12 12:24:08+0200</td></tr><tr><td>Performers</td><td> <a href=\"Organization-72cc3a2c-1dda-4b95-b50a-0f7ac19640f4.html\">Organization Pleje og Rehabilitering</a> <a href=\"PractitionerRole-4b3b6f0f-a475-4b04-8a92-105e8ce6a7bf.html\">PractitionerRole Sygeplejerske</a></td></tr></table><p><b>Report Details</b></p><table class=\"grid\"><tr><td><b>Code</b></td><td><b>Value</b></td><td><b>Flags</b></td><td><b>When For</b></td></tr><tr><td><a href=\"Observation-4b8f899a-df12-4301-8287-9a77d46ded3d.html\"><span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU04206}\">U—Protein; arb.k.(proc.) = ?</span></a></td><td>1 +</td><td>Final, <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></td><td>2023-09-13 12:24:08+0200</td></tr><tr><td><a href=\"Observation-f58819ff-d727-4740-a4ef-44eefc77022e.html\"><span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU21578}\">U—Nitrit; arb.k.(proc.) = ?</span></a></td><td>Negative</td><td>Final, <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></td><td>2023-09-13 12:24:08+0200</td></tr><tr><td><a href=\"Observation-2fc2c078-825b-491d-9f8e-34926eb4f06f.html\"><span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU03987}\">U—Leukocytter; arb.k.(proc.) = ?</span></a></td><td>2 +</td><td>Final, <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></td><td>2023-09-13 12:24:08+0200</td></tr></table></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/MedComDiagnosticReportCodes",
              "code" : "HomeCareReport"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/733cef33-3626-422b-955d-d506aaa65fe1"
        },
        "issued" : "2023-09-12T12:24:08+02:00",
        "performer" : [
          {
            "reference" : "Organization/72cc3a2c-1dda-4b95-b50a-0f7ac19640f4"
          },
          {
            "reference" : "PractitionerRole/4b3b6f0f-a475-4b04-8a92-105e8ce6a7bf"
          }
        ],
        "result" : [
          {
            "reference" : "Observation/4b8f899a-df12-4301-8287-9a77d46ded3d"
          },
          {
            "reference" : "Observation/f58819ff-d727-4740-a4ef-44eefc77022e"
          },
          {
            "reference" : "Observation/2fc2c078-825b-491d-9f8e-34926eb4f06f"
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/PractitionerRole/4b3b6f0f-a475-4b04-8a92-105e8ce6a7bf",
      "resource" : {
        "resourceType" : "PractitionerRole",
        "id" : "4b3b6f0f-a475-4b04-8a92-105e8ce6a7bf",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-practitionerrole"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_4b3b6f0f-a475-4b04-8a92-105e8ce6a7bf\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole 4b3b6f0f-a475-4b04-8a92-105e8ce6a7bf</b></p><a name=\"4b3b6f0f-a475-4b04-8a92-105e8ce6a7bf\"> </a><a name=\"hc4b3b6f0f-a475-4b04-8a92-105e8ce6a7bf\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/2.4.0/StructureDefinition-medcom-core-practitionerrole.html\">MedComCorePractitionerRole</a></p></div><p><b>practitioner</b>: <a href=\"Practitioner-be9f367d-a84a-4815-90a8-c83a03813fd8.html\">Practitioner Mia </a></p><p><b>code</b>: <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-PractitionerRolesSKSadministrativ sygeplejerske}\">Sygeplejerske</span></p></div>"
        },
        "practitioner" : {
          "reference" : "Practitioner/be9f367d-a84a-4815-90a8-c83a03813fd8"
        },
        "code" : [
          {
            "coding" : [
              {
                "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-PractitionerRolesSKSadministrativ",
                "code" : "sygeplejerske"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Practitioner/be9f367d-a84a-4815-90a8-c83a03813fd8",
      "resource" : {
        "resourceType" : "Practitioner",
        "id" : "be9f367d-a84a-4815-90a8-c83a03813fd8",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-practitioner"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_be9f367d-a84a-4815-90a8-c83a03813fd8\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner be9f367d-a84a-4815-90a8-c83a03813fd8</b></p><a name=\"be9f367d-a84a-4815-90a8-c83a03813fd8\"> </a><a name=\"hcbe9f367d-a84a-4815-90a8-c83a03813fd8\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/2.4.0/StructureDefinition-medcom-core-practitioner.html\">MedComCorePractitioner</a></p></div><p><b>name</b>: Mia </p><p><b>telecom</b>: <a href=\"tel:+4505577668\">+45 05577668</a></p></div>"
        },
        "name" : [
          {
            "given" : ["Mia"]
          }
        ],
        "telecom" : [
          {
            "system" : "phone",
            "value" : "+45 05577668"
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Organization/72cc3a2c-1dda-4b95-b50a-0f7ac19640f4",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "72cc3a2c-1dda-4b95-b50a-0f7ac19640f4",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-producer-organization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_72cc3a2c-1dda-4b95-b50a-0f7ac19640f4\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization 72cc3a2c-1dda-4b95-b50a-0f7ac19640f4</b></p><a name=\"72cc3a2c-1dda-4b95-b50a-0f7ac19640f4\"> </a><a name=\"hc72cc3a2c-1dda-4b95-b50a-0f7ac19640f4\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/3.0.0/StructureDefinition-medcom-producer-organization.html\">MedComCoreProducerOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790000123117, <code>urn:oid:1.2.208.176.1.1</code>/1144561000016002, <code>http://medcomfhir.dk/ig/terminology/CodeSystem/MedComProducentID</code>/KAF</p><p><b>name</b>: Pleje og Rehabilitering</p></div>"
        },
        "identifier" : [
          {
            "system" : "https://www.gs1.org/gln",
            "value" : "5790000123117"
          },
          {
            "system" : "urn:oid:1.2.208.176.1.1",
            "value" : "1144561000016002"
          },
          {
            "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/MedComProducentID",
            "value" : "KAF"
          }
        ],
        "name" : "Pleje og Rehabilitering"
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Organization/d1c1fa90-2c7e-4dd7-b2e8-e40281635a98",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "d1c1fa90-2c7e-4dd7-b2e8-e40281635a98",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-requesterorganization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_d1c1fa90-2c7e-4dd7-b2e8-e40281635a98\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization d1c1fa90-2c7e-4dd7-b2e8-e40281635a98</b></p><a name=\"d1c1fa90-2c7e-4dd7-b2e8-e40281635a98\"> </a><a name=\"hcd1c1fa90-2c7e-4dd7-b2e8-e40281635a98\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/3.0.0/StructureDefinition-medcom-requesterorganization.html\">MedComMessagingRequesterOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790000127092, <code>urn:oid:1.2.208.176.1.1</code>/52581000016005, <code>urn:oid:1.2.208.176.1.4</code>/061654</p><p><b>name</b>: Skødstrup Lægepraksis</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td></tr><tr><td style=\"display: none\">*</td><td>OKM </td></tr></table></div>"
        },
        "identifier" : [
          {
            "system" : "https://www.gs1.org/gln",
            "value" : "5790000127092"
          },
          {
            "system" : "urn:oid:1.2.208.176.1.1",
            "value" : "52581000016005"
          },
          {
            "system" : "urn:oid:1.2.208.176.1.4",
            "value" : "061654"
          }
        ],
        "name" : "Skødstrup Lægepraksis",
        "contact" : [
          {
            "name" : {
              "given" : ["OKM"]
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Provenance/4c845e97-04b2-40e9-ab51-4c5bf080196f",
      "resource" : {
        "resourceType" : "Provenance",
        "id" : "4c845e97-04b2-40e9-ab51-4c5bf080196f",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-provenance"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_4c845e97-04b2-40e9-ab51-4c5bf080196f\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance 4c845e97-04b2-40e9-ab51-4c5bf080196f</b></p><a name=\"4c845e97-04b2-40e9-ab51-4c5bf080196f\"> </a><a name=\"hc4c845e97-04b2-40e9-ab51-4c5bf080196f\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/3.0.0/StructureDefinition-medcom-messaging-provenance.html\">MedComMessagingProvenance</a></p></div><p>Provenance for <a href=\"MessageHeader-e9f4cc68-b1b7-46b2-ba74-7cc39a914bfa.html\">MessageHeader: event[x] = HomeCare Observation Message (MedComMessagingEventCodes#homecareobservation-message); definition = http://medcomfhir.dk/ig/messagedefinitions/MessageDefinition/MedComHomeCareObservationMessageDefinition|1.1</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>2023-09-13 12:24:08+0200</td></tr><tr><td>Recorded</td><td>2023-09-13 12:24:08+0200</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes new-message}\">A new message has been sent</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>who</b></td></tr><tr><td><a href=\"Organization-72cc3a2c-1dda-4b95-b50a-0f7ac19640f4.html\">Organization Pleje og Rehabilitering</a></td></tr></table></div>"
        },
        "target" : [
          {
            "reference" : "MessageHeader/e9f4cc68-b1b7-46b2-ba74-7cc39a914bfa"
          }
        ],
        "occurredDateTime" : "2023-09-13T12:24:08+02:00",
        "recorded" : "2023-09-13T12:24:08+02:00",
        "activity" : {
          "coding" : [
            {
              "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes",
              "code" : "new-message"
            }
          ]
        },
        "agent" : [
          {
            "who" : {
              "reference" : "Organization/72cc3a2c-1dda-4b95-b50a-0f7ac19640f4"
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Observation/4b8f899a-df12-4301-8287-9a77d46ded3d",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "4b8f899a-df12-4301-8287-9a77d46ded3d",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/homecareobservation/StructureDefinition/medcom-homecare-observation"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_4b8f899a-df12-4301-8287-9a77d46ded3d\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation 4b8f899a-df12-4301-8287-9a77d46ded3d</b></p><a name=\"4b8f899a-df12-4301-8287-9a77d46ded3d\"> </a><a name=\"hc4b8f899a-df12-4301-8287-9a77d46ded3d\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-homecare-observation.html\">MedComHomeCareObservation</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU04206}\">U—Protein; arb.k.(proc.) = ?</span></p><p><b>subject</b>: <a href=\"Patient-733cef33-3626-422b-955d-d506aaa65fe1.html\">Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</a></p><p><b>effective</b>: 2023-09-13 12:24:08+0200</p><p><b>value</b>: 1 +</p><p><b>interpretation</b>: <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "urn:oid:1.2.208.176.2.1",
              "code" : "NPU04206",
              "display" : "U—Protein; arb.k.(proc.) = ?"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/733cef33-3626-422b-955d-d506aaa65fe1"
        },
        "effectiveDateTime" : "2023-09-13T12:24:08+02:00",
        "valueQuantity" : {
          "value" : 1,
          "unit" : "+"
        },
        "interpretation" : [
          {
            "coding" : [
              {
                "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes",
                "code" : "NI",
                "display" : "Not Interpreted"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Observation/f58819ff-d727-4740-a4ef-44eefc77022e",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "f58819ff-d727-4740-a4ef-44eefc77022e",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/homecareobservation/StructureDefinition/medcom-homecare-observation"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_f58819ff-d727-4740-a4ef-44eefc77022e\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation f58819ff-d727-4740-a4ef-44eefc77022e</b></p><a name=\"f58819ff-d727-4740-a4ef-44eefc77022e\"> </a><a name=\"hcf58819ff-d727-4740-a4ef-44eefc77022e\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-homecare-observation.html\">MedComHomeCareObservation</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU21578}\">U—Nitrit; arb.k.(proc.) = ?</span></p><p><b>subject</b>: <a href=\"Patient-733cef33-3626-422b-955d-d506aaa65fe1.html\">Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</a></p><p><b>effective</b>: 2023-09-13 12:24:08+0200</p><p><b>value</b>: Negative</p><p><b>interpretation</b>: <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "urn:oid:1.2.208.176.2.1",
              "code" : "NPU21578",
              "display" : "U—Nitrit; arb.k.(proc.) = ?"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/733cef33-3626-422b-955d-d506aaa65fe1"
        },
        "effectiveDateTime" : "2023-09-13T12:24:08+02:00",
        "valueString" : "Negative",
        "interpretation" : [
          {
            "coding" : [
              {
                "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes",
                "code" : "NI",
                "display" : "Not Interpreted"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Observation/2fc2c078-825b-491d-9f8e-34926eb4f06f",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "2fc2c078-825b-491d-9f8e-34926eb4f06f",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/homecareobservation/StructureDefinition/medcom-homecare-observation"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_2fc2c078-825b-491d-9f8e-34926eb4f06f\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation 2fc2c078-825b-491d-9f8e-34926eb4f06f</b></p><a name=\"2fc2c078-825b-491d-9f8e-34926eb4f06f\"> </a><a name=\"hc2fc2c078-825b-491d-9f8e-34926eb4f06f\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-homecare-observation.html\">MedComHomeCareObservation</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU03987}\">U—Leukocytter; arb.k.(proc.) = ?</span></p><p><b>subject</b>: <a href=\"Patient-733cef33-3626-422b-955d-d506aaa65fe1.html\">Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</a></p><p><b>effective</b>: 2023-09-13 12:24:08+0200</p><p><b>value</b>: 2 +</p><p><b>interpretation</b>: <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "urn:oid:1.2.208.176.2.1",
              "code" : "NPU03987",
              "display" : "U—Leukocytter; arb.k.(proc.) = ?"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/733cef33-3626-422b-955d-d506aaa65fe1"
        },
        "effectiveDateTime" : "2023-09-13T12:24:08+02:00",
        "valueQuantity" : {
          "value" : 2,
          "unit" : "+"
        },
        "interpretation" : [
          {
            "coding" : [
              {
                "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes",
                "code" : "NI",
                "display" : "Not Interpreted"
              }
            ]
          }
        ]
      }
    }
  ]
}

```
