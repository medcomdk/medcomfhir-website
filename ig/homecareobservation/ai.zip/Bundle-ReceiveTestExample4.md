# ReceiveTestExample4 - MedCom HomeCareObservation v1.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ReceiveTestExample4**

## Example Bundle: ReceiveTestExample4



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "ReceiveTestExample4",
  "meta" : {
    "profile" : [
      "http://medcomfhir.dk/ig/homecareobservation/StructureDefinition/medcom-homecareobservation-message"
    ]
  },
  "type" : "message",
  "timestamp" : "2025-08-08T15:00:00+02:00",
  "entry" : [
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/MessageHeader/ReceiveTestExample4-MessageHeader",
      "resource" : {
        "resourceType" : "MessageHeader",
        "id" : "ReceiveTestExample4-MessageHeader",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/homecareobservation/StructureDefinition/medcom-homecareobservation-messageheader"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_ReceiveTestExample4-MessageHeader\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader ReceiveTestExample4-MessageHeader</b></p><a name=\"ReceiveTestExample4-MessageHeader\"> </a><a name=\"hcReceiveTestExample4-MessageHeader\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-homecareobservation-messageheader.html\">MedComHomeCareObservationMessageHeader</a></p></div><p><b>event</b>: <a href=\"http://medcomfhir.dk/ig/terminology/2.0.2/CodeSystem-medcom-messaging-eventCodes.html#medcom-messaging-eventCodes-homecareobservation-message\">MedComMessagingEventCodes: homecareobservation-message</a> (HomeCare Observation Message)</p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Endpoint</b></td><td><b>Receiver</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><a href=\"https://sor2.sum.dsdn.dk/#id=73091000016008\">https://sor2.sum.dsdn.dk/#id=73091000016008</a></td><td><a href=\"Bundle-ReceiveTestExample1.html#Organization_AgerskovsLaegePraksisRequesterOrgKnownDr\">Organization Agerskov lægepraksis</a></td></tr></table><p><b>sender</b>: <a href=\"Bundle-ReceiveTestExample1.html#Organization_SkovlyAktivitetstilbudProducerOrg\">Organization Pleje og Rehabilitering</a></p><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://sor2.sum.dsdn.dk/#id=1267041000016006\">https://sor2.sum.dsdn.dk/#id=1267041000016006</a></td></tr></table><p><b>focus</b>: <a href=\"Bundle-ReceiveTestExample4.html#DiagnosticReport_ReceiveTestExample4-DiagnosticReport\">Diagnostic Report for 'HomeCareDiagnosticReport' for '-&gt;Bruno Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)'</a></p><p><b>definition</b>: <a href=\"http://medcomfhir.dk/ig/messagedefinitions/1.0.1-trial-use/MessageDefinition-MedComHomeCareObservationMessageDefinitionV1.1.html\">http://medcomfhir.dk/ig/messagedefinitions/MessageDefinition/MedComHomeCareObservationMessageDefinition|1.1</a></p></div>"
        },
        "eventCoding" : {
          "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-eventCodes",
          "code" : "homecareobservation-message"
        },
        "destination" : [
          {
            "extension" : [
              {
                "url" : "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-destinationUseExtension",
                "valueCoding" : {
                  "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-destinationUse",
                  "code" : "primary"
                }
              }
            ],
            "endpoint" : "https://sor2.sum.dsdn.dk/#id=73091000016008",
            "receiver" : {
              "reference" : "Organization/AgerskovsLaegePraksisRequesterOrgKnownDr"
            }
          }
        ],
        "sender" : {
          "reference" : "Organization/SkovlyAktivitetstilbudProducerOrg"
        },
        "source" : {
          "endpoint" : "https://sor2.sum.dsdn.dk/#id=1267041000016006"
        },
        "focus" : [
          {
            "reference" : "DiagnosticReport/ReceiveTestExample4-DiagnosticReport"
          }
        ],
        "definition" : "http://medcomfhir.dk/ig/messagedefinitions/MessageDefinition/MedComHomeCareObservationMessageDefinition|1.1"
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Patient/BrunoElmerPatient",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "BrunoElmerPatient",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_BrunoElmerPatient\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient BrunoElmerPatient</b></p><a name=\"BrunoElmerPatient\"> </a><a name=\"hcBrunoElmerPatient\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/2.4.0/StructureDefinition-medcom-core-patient.html\">MedComCorePatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Bruno Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</p><hr/></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:1.2.208.176.1.2",
            "value" : "2509479989"
          }
        ],
        "name" : [
          {
            "use" : "official",
            "family" : "Elmer",
            "given" : ["Bruno"]
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/DiagnosticReport/ReceiveTestExample4-DiagnosticReport",
      "resource" : {
        "resourceType" : "DiagnosticReport",
        "id" : "ReceiveTestExample4-DiagnosticReport",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/homecareobservation/StructureDefinition/medcom-homecareobservation-diagnosticreport"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DiagnosticReport_ReceiveTestExample4-DiagnosticReport\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DiagnosticReport ReceiveTestExample4-DiagnosticReport</b></p><a name=\"ReceiveTestExample4-DiagnosticReport\"> </a><a name=\"hcReceiveTestExample4-DiagnosticReport\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-homecareobservation-diagnosticreport.html\">MedComHomeCareObservationDiagnosticReport</a></p></div><h2><span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/MedComDiagnosticReportCodes HomeCareReport}\">HomeCareDiagnosticReport</span> </h2><table class=\"grid\"><tr><td>Subject</td><td>Bruno Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</td></tr><tr><td>Reported</td><td>2025-08-07 15:00:00+0200</td></tr><tr><td>Performers</td><td> <a href=\"Bundle-ReceiveTestExample1.html#Organization_SkovlyAktivitetstilbudProducerOrg\">Organization Pleje og Rehabilitering</a> <a href=\"Bundle-ReceiveTestExample1.html#PractitionerRole_JohnAcuteNursePractitionerRole\">PractitionerRole Sygeplejerske</a></td></tr></table><p><b>Report Details</b></p><table class=\"grid\"><tr><td><b>Code</b></td><td><b>Value</b></td><td><b>Flags</b></td><td><b>Note</b></td><td><b>When For</b></td></tr><tr><td><a href=\"Bundle-ReceiveTestExample1.html#Observation_GlucoseObservationOnBrunoNoComment\"><span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU22089}\">P(kB)—Glucose; stofk. = ? mmol/L</span></a></td><td>6.8 mmol/L</td><td>Final, <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></td><td/><td>2025-08-07 14:47:23+0200</td></tr><tr><td><a href=\"Bundle-ReceiveTestExample4.html#Observation_HighRespirationObservationOnBrunoNoComment\"><span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-observation-codes MCS88122}\">Pt—Respiration; frekvens = ? X 1/min</span></a></td><td>&gt;25 1/min</td><td>Final, <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></td><td/><td>2025-08-06 22:44:01+0200</td></tr><tr><td><a href=\"Bundle-ReceiveTestExample1.html#Observation_CReaktiveProteinObservationOnBrunoNoComment\"><span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU19748}\">P—C-reaktivt protein; massek. = ? mg/L</span></a></td><td>26 mg/L</td><td>Final, <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></td><td/><td>2025-08-06 13:25:23+0200</td></tr><tr><td><a href=\"Bundle-ReceiveTestExample4.html#Observation_HaemoglobinObservationOnBrunoWithComment\"><span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU02319}\">NPU02319</span></a></td><td>7.8 mmol/L</td><td>Final, <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></td><td><blockquote><div><p>Lorem Ipsum dolor sit amet, consectetur adipiscing elit.</p>\n</div></blockquote></td><td>2025-08-07 13:45:23+0200</td></tr><tr><td><a href=\"Bundle-ReceiveTestExample4.html#Observation_LeukocytObservationOnBrunoWithComment\"><span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU02593}\">B—Leukocytter; antalk. = ? × 10^9/L</span></a></td><td>8.1 10^9/L</td><td>Final, <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></td><td><blockquote><div><p>Lorem Ipsum dolor sit amet, consectetur adipiscing elit.</p>\n</div></blockquote></td><td>2025-08-07 14:45:08+0200</td></tr><tr><td><a href=\"Bundle-ReceiveTestExample4.html#Observation_LymphocyteObservationOnBrunoWithComment\"><span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU02636}\">B—Leukocytter; antalk. = ? × 10^9/L</span></a></td><td>2.7 10^9/L</td><td>Final, <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></td><td><blockquote><div><p>Lorem Ipsum dolor sit amet, consectetur adipiscing elit.</p>\n</div></blockquote></td><td>2025-08-07 14:45:08+0200</td></tr><tr><td><a href=\"Bundle-ReceiveTestExample4.html#Observation_MonocytesObservationOnBrunoWithComment\"><span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU02840}\">B—Monocytter; antalk. = ? × 10^9/L</span></a></td><td>0.8 10^9/L</td><td>Final, <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></td><td><blockquote><div><p>Lorem Ipsum dolor sit amet, consectetur adipiscing elit.</p>\n</div></blockquote></td><td>2025-08-07 14:32:08+0200</td></tr><tr><td><a href=\"Bundle-ReceiveTestExample4.html#Observation_NeutrophilocytesObservationOnBrunoWithComment\"><span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU02902}\">B—Neutrophilocytter; antalk. = ? × 10^9/L</span></a></td><td>10.2 10^9/L</td><td>Final, <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></td><td><blockquote><div><p>Lorem Ipsum dolor sit amet, consectetur adipiscing elit.</p>\n</div></blockquote></td><td>2025-08-07 14:34:08+0200</td></tr><tr><td><a href=\"Bundle-ReceiveTestExample4.html#Observation_EosinofilocytObservationOnBrunoWithComment\"><span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU01933}\">B—Eosinophilocytter; antalk. = ? × 10^9/L</span></a></td><td>0.11 10^9/L</td><td>Final, <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></td><td><blockquote><div><p>Lorem Ipsum dolor sit amet, consectetur adipiscing elit.</p>\n</div></blockquote></td><td>2025-08-07 14:36:08+0200</td></tr></table><p>All observations are within normal limits, except for the heart rate which is elevated after exercise. Further monitoring is recommended.\nLorem Ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\nSed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi</p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/MedComDiagnosticReportCodes",
              "code" : "HomeCareReport"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/BrunoElmerPatient"
        },
        "issued" : "2025-08-07T15:00:00+02:00",
        "performer" : [
          {
            "reference" : "Organization/SkovlyAktivitetstilbudProducerOrg"
          },
          {
            "reference" : "PractitionerRole/JohnAcuteNursePractitionerRole"
          }
        ],
        "result" : [
          {
            "reference" : "Observation/GlucoseObservationOnBrunoNoComment"
          },
          {
            "reference" : "Observation/HighRespirationObservationOnBrunoNoComment"
          },
          {
            "reference" : "Observation/CReaktiveProteinObservationOnBrunoNoComment"
          },
          {
            "reference" : "Observation/HaemoglobinObservationOnBrunoWithComment"
          },
          {
            "reference" : "Observation/LeukocytObservationOnBrunoWithComment"
          },
          {
            "reference" : "Observation/LymphocyteObservationOnBrunoWithComment"
          },
          {
            "reference" : "Observation/MonocytesObservationOnBrunoWithComment"
          },
          {
            "reference" : "Observation/NeutrophilocytesObservationOnBrunoWithComment"
          },
          {
            "reference" : "Observation/EosinofilocytObservationOnBrunoWithComment"
          }
        ],
        "conclusion" : "All observations are within normal limits, except for the heart rate which is elevated after exercise. Further monitoring is recommended.\nLorem Ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\nSed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi"
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/PractitionerRole/JohnAcuteNursePractitionerRole",
      "resource" : {
        "resourceType" : "PractitionerRole",
        "id" : "JohnAcuteNursePractitionerRole",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-practitionerrole"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_JohnAcuteNursePractitionerRole\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole JohnAcuteNursePractitionerRole</b></p><a name=\"JohnAcuteNursePractitionerRole\"> </a><a name=\"hcJohnAcuteNursePractitionerRole\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/2.4.0/StructureDefinition-medcom-core-practitionerrole.html\">MedComCorePractitionerRole</a></p></div><p><b>practitioner</b>: <a href=\"Bundle-ReceiveTestExample1.html#Practitioner_JohnAcuteNurse\">Practitioner John Pedersen </a></p><p><b>code</b>: <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-PractitionerRolesSKSadministrativ sygeplejerske}\">Sygeplejerske</span></p></div>"
        },
        "practitioner" : {
          "reference" : "Practitioner/JohnAcuteNurse"
        },
        "code" : [
          {
            "coding" : [
              {
                "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-PractitionerRolesSKSadministrativ",
                "code" : "sygeplejerske"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Practitioner/JohnAcuteNurse",
      "resource" : {
        "resourceType" : "Practitioner",
        "id" : "JohnAcuteNurse",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-practitioner"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_JohnAcuteNurse\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner JohnAcuteNurse</b></p><a name=\"JohnAcuteNurse\"> </a><a name=\"hcJohnAcuteNurse\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/2.4.0/StructureDefinition-medcom-core-practitioner.html\">MedComCorePractitioner</a></p></div><p><b>name</b>: John Pedersen </p><p><b>telecom</b>: <a href=\"tel:+4505577668\">+45 05577668</a></p></div>"
        },
        "name" : [
          {
            "family" : "Pedersen",
            "given" : ["John"]
          }
        ],
        "telecom" : [
          {
            "system" : "phone",
            "value" : "+45 05577668"
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Organization/AgerskovsLaegePraksisRequesterOrgKnownDr",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "AgerskovsLaegePraksisRequesterOrgKnownDr",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-requesterorganization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_AgerskovsLaegePraksisRequesterOrgKnownDr\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization AgerskovsLaegePraksisRequesterOrgKnownDr</b></p><a name=\"AgerskovsLaegePraksisRequesterOrgKnownDr\"> </a><a name=\"hcAgerskovsLaegePraksisRequesterOrgKnownDr\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/3.0.0/StructureDefinition-medcom-requesterorganization.html\">MedComMessagingRequesterOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790000147465, <code>urn:oid:1.2.208.176.1.1</code>/73091000016008, <code>urn:oid:1.2.208.176.1.4</code>/045861</p><p><b>name</b>: Agerskov lægepraksis</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td></tr><tr><td style=\"display: none\">*</td><td>Some Doctor at Agerskov(Official)</td></tr></table></div>"
        },
        "identifier" : [
          {
            "system" : "https://www.gs1.org/gln",
            "value" : "5790000147465"
          },
          {
            "system" : "urn:oid:1.2.208.176.1.1",
            "value" : "73091000016008"
          },
          {
            "system" : "urn:oid:1.2.208.176.1.4",
            "value" : "045861"
          }
        ],
        "name" : "Agerskov lægepraksis",
        "contact" : [
          {
            "name" : {
              "use" : "official",
              "text" : "Some Doctor at Agerskov",
              "family" : "Andersen",
              "given" : ["SDaA"]
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Organization/SkovlyAktivitetstilbudProducerOrg",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "SkovlyAktivitetstilbudProducerOrg",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-producer-organization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_SkovlyAktivitetstilbudProducerOrg\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization SkovlyAktivitetstilbudProducerOrg</b></p><a name=\"SkovlyAktivitetstilbudProducerOrg\"> </a><a name=\"hcSkovlyAktivitetstilbudProducerOrg\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/3.0.0/StructureDefinition-medcom-producer-organization.html\">MedComCoreProducerOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790002757778, <code>urn:oid:1.2.208.176.1.1</code>/1267041000016006, <code>http://medcomfhir.dk/ig/terminology/CodeSystem/MedComProducentID</code>/KAF</p><p><b>name</b>: Pleje og Rehabilitering</p></div>"
        },
        "identifier" : [
          {
            "system" : "https://www.gs1.org/gln",
            "value" : "5790002757778"
          },
          {
            "system" : "urn:oid:1.2.208.176.1.1",
            "value" : "1267041000016006"
          },
          {
            "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/MedComProducentID",
            "value" : "KAF"
          }
        ],
        "name" : "Pleje og Rehabilitering"
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Provenance/ReceiveTestExample4-Provenance",
      "resource" : {
        "resourceType" : "Provenance",
        "id" : "ReceiveTestExample4-Provenance",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-provenance"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_ReceiveTestExample4-Provenance\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance ReceiveTestExample4-Provenance</b></p><a name=\"ReceiveTestExample4-Provenance\"> </a><a name=\"hcReceiveTestExample4-Provenance\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/3.0.0/StructureDefinition-medcom-messaging-provenance.html\">MedComMessagingProvenance</a></p></div><p>Provenance for <a href=\"Bundle-ReceiveTestExample4.html#MessageHeader_ReceiveTestExample4-MessageHeader\">MessageHeader: event[x] = HomeCare Observation Message (MedComMessagingEventCodes#homecareobservation-message); definition = http://medcomfhir.dk/ig/messagedefinitions/MessageDefinition/MedComHomeCareObservationMessageDefinition|1.1</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>2025-08-07 15:00:00+0200</td></tr><tr><td>Recorded</td><td>2025-08-07 15:00:00+0200</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes new-message}\">A new message has been sent</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>who</b></td></tr><tr><td><a href=\"Bundle-ReceiveTestExample1.html#Organization_SkovlyAktivitetstilbudProducerOrg\">Organization Pleje og Rehabilitering</a></td></tr></table></div>"
        },
        "target" : [
          {
            "reference" : "MessageHeader/ReceiveTestExample4-MessageHeader"
          }
        ],
        "occurredDateTime" : "2025-08-07T15:00:00+02:00",
        "recorded" : "2025-08-07T15:00:00+02:00",
        "activity" : {
          "coding" : [
            {
              "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes",
              "code" : "new-message"
            }
          ]
        },
        "agent" : [
          {
            "who" : {
              "reference" : "Organization/SkovlyAktivitetstilbudProducerOrg"
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Observation/GlucoseObservationOnBrunoNoComment",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "GlucoseObservationOnBrunoNoComment",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/homecareobservation/StructureDefinition/medcom-homecare-observation"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_GlucoseObservationOnBrunoNoComment\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation GlucoseObservationOnBrunoNoComment</b></p><a name=\"GlucoseObservationOnBrunoNoComment\"> </a><a name=\"hcGlucoseObservationOnBrunoNoComment\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-homecare-observation.html\">MedComHomeCareObservation</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU22089}\">P(kB)—Glucose; stofk. = ? mmol/L</span></p><p><b>subject</b>: <a href=\"Bundle-ReceiveTestExample1.html#Patient_BrunoElmerPatient\">Bruno Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</a></p><p><b>effective</b>: 2025-08-07 14:47:23+0200</p><p><b>value</b>: 6.8 mmol/L</p><p><b>interpretation</b>: <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "urn:oid:1.2.208.176.2.1",
              "code" : "NPU22089",
              "display" : "P(kB)—Glucose; stofk. = ? mmol/L"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/BrunoElmerPatient"
        },
        "effectiveDateTime" : "2025-08-07T14:47:23+02:00",
        "valueQuantity" : {
          "value" : 6.8,
          "unit" : "mmol/L"
        },
        "interpretation" : [
          {
            "coding" : [
              {
                "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes",
                "code" : "NI",
                "display" : "Not Interpreted"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Observation/HighRespirationObservationOnBrunoNoComment",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "HighRespirationObservationOnBrunoNoComment",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/homecareobservation/StructureDefinition/medcom-homecare-observation"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_HighRespirationObservationOnBrunoNoComment\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation HighRespirationObservationOnBrunoNoComment</b></p><a name=\"HighRespirationObservationOnBrunoNoComment\"> </a><a name=\"hcHighRespirationObservationOnBrunoNoComment\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-homecare-observation.html\">MedComHomeCareObservation</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-observation-codes MCS88122}\">Pt—Respiration; frekvens = ? X 1/min</span></p><p><b>subject</b>: <a href=\"Bundle-ReceiveTestExample1.html#Patient_BrunoElmerPatient\">Bruno Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</a></p><p><b>effective</b>: 2025-08-06 22:44:01+0200</p><p><b>value</b>: &gt;25 1/min</p><p><b>interpretation</b>: <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-observation-codes",
              "code" : "MCS88122",
              "display" : "Pt—Respiration; frekvens = ? X 1/min"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/BrunoElmerPatient"
        },
        "effectiveDateTime" : "2025-08-06T22:44:01+02:00",
        "valueQuantity" : {
          "value" : 25,
          "comparator" : ">",
          "unit" : "1/min"
        },
        "interpretation" : [
          {
            "coding" : [
              {
                "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes",
                "code" : "NI",
                "display" : "Not Interpreted"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Observation/CReaktiveProteinObservationOnBrunoNoComment",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "CReaktiveProteinObservationOnBrunoNoComment",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/homecareobservation/StructureDefinition/medcom-homecare-observation"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_CReaktiveProteinObservationOnBrunoNoComment\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation CReaktiveProteinObservationOnBrunoNoComment</b></p><a name=\"CReaktiveProteinObservationOnBrunoNoComment\"> </a><a name=\"hcCReaktiveProteinObservationOnBrunoNoComment\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-homecare-observation.html\">MedComHomeCareObservation</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU19748}\">P—C-reaktivt protein; massek. = ? mg/L</span></p><p><b>subject</b>: <a href=\"Bundle-ReceiveTestExample1.html#Patient_BrunoElmerPatient\">Bruno Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</a></p><p><b>effective</b>: 2025-08-06 13:25:23+0200</p><p><b>value</b>: 26 mg/L</p><p><b>interpretation</b>: <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "urn:oid:1.2.208.176.2.1",
              "code" : "NPU19748",
              "display" : "P—C-reaktivt protein; massek. = ? mg/L"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/BrunoElmerPatient"
        },
        "effectiveDateTime" : "2025-08-06T13:25:23+02:00",
        "valueQuantity" : {
          "value" : 26,
          "unit" : "mg/L"
        },
        "interpretation" : [
          {
            "coding" : [
              {
                "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes",
                "code" : "NI",
                "display" : "Not Interpreted"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Observation/HaemoglobinObservationOnBrunoWithComment",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "HaemoglobinObservationOnBrunoWithComment",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/homecareobservation/StructureDefinition/medcom-homecare-observation"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_HaemoglobinObservationOnBrunoWithComment\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation HaemoglobinObservationOnBrunoWithComment</b></p><a name=\"HaemoglobinObservationOnBrunoWithComment\"> </a><a name=\"hcHaemoglobinObservationOnBrunoWithComment\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-homecare-observation.html\">MedComHomeCareObservation</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU02319}\">NPU02319</span></p><p><b>subject</b>: <a href=\"Bundle-ReceiveTestExample1.html#Patient_BrunoElmerPatient\">Bruno Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</a></p><p><b>effective</b>: 2025-08-07 13:45:23+0200</p><p><b>value</b>: 7.8 mmol/L</p><p><b>interpretation</b>: <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></p><p><b>note</b>: </p><blockquote><div><p>Lorem Ipsum dolor sit amet, consectetur adipiscing elit.</p>\n</div></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "urn:oid:1.2.208.176.2.1",
              "code" : "NPU02319"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/BrunoElmerPatient"
        },
        "effectiveDateTime" : "2025-08-07T13:45:23+02:00",
        "valueQuantity" : {
          "value" : 7.8,
          "unit" : "mmol/L"
        },
        "interpretation" : [
          {
            "coding" : [
              {
                "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes",
                "code" : "NI",
                "display" : "Not Interpreted"
              }
            ]
          }
        ],
        "note" : [
          {
            "text" : "Lorem Ipsum dolor sit amet, consectetur adipiscing elit."
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Observation/LeukocytObservationOnBrunoWithComment",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "LeukocytObservationOnBrunoWithComment",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/homecareobservation/StructureDefinition/medcom-homecare-observation"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_LeukocytObservationOnBrunoWithComment\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation LeukocytObservationOnBrunoWithComment</b></p><a name=\"LeukocytObservationOnBrunoWithComment\"> </a><a name=\"hcLeukocytObservationOnBrunoWithComment\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-homecare-observation.html\">MedComHomeCareObservation</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU02593}\">B—Leukocytter; antalk. = ? × 10^9/L</span></p><p><b>subject</b>: <a href=\"Bundle-ReceiveTestExample1.html#Patient_BrunoElmerPatient\">Bruno Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</a></p><p><b>effective</b>: 2025-08-07 14:45:08+0200</p><p><b>value</b>: 8.1 10^9/L</p><p><b>interpretation</b>: <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></p><p><b>note</b>: </p><blockquote><div><p>Lorem Ipsum dolor sit amet, consectetur adipiscing elit.</p>\n</div></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "urn:oid:1.2.208.176.2.1",
              "code" : "NPU02593",
              "display" : "B—Leukocytter; antalk. = ? × 10^9/L"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/BrunoElmerPatient"
        },
        "effectiveDateTime" : "2025-08-07T14:45:08+02:00",
        "valueQuantity" : {
          "value" : 8.1,
          "unit" : "10^9/L"
        },
        "interpretation" : [
          {
            "coding" : [
              {
                "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes",
                "code" : "NI",
                "display" : "Not Interpreted"
              }
            ]
          }
        ],
        "note" : [
          {
            "text" : "Lorem Ipsum dolor sit amet, consectetur adipiscing elit."
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Observation/LymphocyteObservationOnBrunoWithComment",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "LymphocyteObservationOnBrunoWithComment",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/homecareobservation/StructureDefinition/medcom-homecare-observation"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_LymphocyteObservationOnBrunoWithComment\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation LymphocyteObservationOnBrunoWithComment</b></p><a name=\"LymphocyteObservationOnBrunoWithComment\"> </a><a name=\"hcLymphocyteObservationOnBrunoWithComment\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-homecare-observation.html\">MedComHomeCareObservation</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU02636}\">B—Leukocytter; antalk. = ? × 10^9/L</span></p><p><b>subject</b>: <a href=\"Bundle-ReceiveTestExample1.html#Patient_BrunoElmerPatient\">Bruno Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</a></p><p><b>effective</b>: 2025-08-07 14:45:08+0200</p><p><b>value</b>: 2.7 10^9/L</p><p><b>interpretation</b>: <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></p><p><b>note</b>: </p><blockquote><div><p>Lorem Ipsum dolor sit amet, consectetur adipiscing elit.</p>\n</div></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "urn:oid:1.2.208.176.2.1",
              "code" : "NPU02636",
              "display" : "B—Leukocytter; antalk. = ? × 10^9/L"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/BrunoElmerPatient"
        },
        "effectiveDateTime" : "2025-08-07T14:45:08+02:00",
        "valueQuantity" : {
          "value" : 2.7,
          "unit" : "10^9/L"
        },
        "interpretation" : [
          {
            "coding" : [
              {
                "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes",
                "code" : "NI",
                "display" : "Not Interpreted"
              }
            ]
          }
        ],
        "note" : [
          {
            "text" : "Lorem Ipsum dolor sit amet, consectetur adipiscing elit."
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Observation/MonocytesObservationOnBrunoWithComment",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "MonocytesObservationOnBrunoWithComment",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/homecareobservation/StructureDefinition/medcom-homecare-observation"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_MonocytesObservationOnBrunoWithComment\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation MonocytesObservationOnBrunoWithComment</b></p><a name=\"MonocytesObservationOnBrunoWithComment\"> </a><a name=\"hcMonocytesObservationOnBrunoWithComment\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-homecare-observation.html\">MedComHomeCareObservation</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU02840}\">B—Monocytter; antalk. = ? × 10^9/L</span></p><p><b>subject</b>: <a href=\"Bundle-ReceiveTestExample1.html#Patient_BrunoElmerPatient\">Bruno Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</a></p><p><b>effective</b>: 2025-08-07 14:32:08+0200</p><p><b>value</b>: 0.8 10^9/L</p><p><b>interpretation</b>: <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></p><p><b>note</b>: </p><blockquote><div><p>Lorem Ipsum dolor sit amet, consectetur adipiscing elit.</p>\n</div></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "urn:oid:1.2.208.176.2.1",
              "code" : "NPU02840",
              "display" : "B—Monocytter; antalk. = ? × 10^9/L"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/BrunoElmerPatient"
        },
        "effectiveDateTime" : "2025-08-07T14:32:08+02:00",
        "valueQuantity" : {
          "value" : 0.8,
          "unit" : "10^9/L"
        },
        "interpretation" : [
          {
            "coding" : [
              {
                "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes",
                "code" : "NI",
                "display" : "Not Interpreted"
              }
            ]
          }
        ],
        "note" : [
          {
            "text" : "Lorem Ipsum dolor sit amet, consectetur adipiscing elit."
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Observation/NeutrophilocytesObservationOnBrunoWithComment",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "NeutrophilocytesObservationOnBrunoWithComment",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/homecareobservation/StructureDefinition/medcom-homecare-observation"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_NeutrophilocytesObservationOnBrunoWithComment\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation NeutrophilocytesObservationOnBrunoWithComment</b></p><a name=\"NeutrophilocytesObservationOnBrunoWithComment\"> </a><a name=\"hcNeutrophilocytesObservationOnBrunoWithComment\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-homecare-observation.html\">MedComHomeCareObservation</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU02902}\">B—Neutrophilocytter; antalk. = ? × 10^9/L</span></p><p><b>subject</b>: <a href=\"Bundle-ReceiveTestExample1.html#Patient_BrunoElmerPatient\">Bruno Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</a></p><p><b>effective</b>: 2025-08-07 14:34:08+0200</p><p><b>value</b>: 10.2 10^9/L</p><p><b>interpretation</b>: <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></p><p><b>note</b>: </p><blockquote><div><p>Lorem Ipsum dolor sit amet, consectetur adipiscing elit.</p>\n</div></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "urn:oid:1.2.208.176.2.1",
              "code" : "NPU02902",
              "display" : "B—Neutrophilocytter; antalk. = ? × 10^9/L"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/BrunoElmerPatient"
        },
        "effectiveDateTime" : "2025-08-07T14:34:08+02:00",
        "valueQuantity" : {
          "value" : 10.2,
          "unit" : "10^9/L"
        },
        "interpretation" : [
          {
            "coding" : [
              {
                "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes",
                "code" : "NI",
                "display" : "Not Interpreted"
              }
            ]
          }
        ],
        "note" : [
          {
            "text" : "Lorem Ipsum dolor sit amet, consectetur adipiscing elit."
          }
        ]
      }
    },
    {
      "fullUrl" : "http://medcomfhir.dk/ig/homecareobservation/Observation/EosinofilocytObservationOnBrunoWithComment",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "EosinofilocytObservationOnBrunoWithComment",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/homecareobservation/StructureDefinition/medcom-homecare-observation"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_EosinofilocytObservationOnBrunoWithComment\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation EosinofilocytObservationOnBrunoWithComment</b></p><a name=\"EosinofilocytObservationOnBrunoWithComment\"> </a><a name=\"hcEosinofilocytObservationOnBrunoWithComment\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-homecare-observation.html\">MedComHomeCareObservation</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{urn:oid:1.2.208.176.2.1 NPU01933}\">B—Eosinophilocytter; antalk. = ? × 10^9/L</span></p><p><b>subject</b>: <a href=\"Bundle-ReceiveTestExample1.html#Patient_BrunoElmerPatient\">Bruno Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</a></p><p><b>effective</b>: 2025-08-07 14:36:08+0200</p><p><b>value</b>: 0.11 10^9/L</p><p><b>interpretation</b>: <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes NI}\">Not Interpreted</span></p><p><b>note</b>: </p><blockquote><div><p>Lorem Ipsum dolor sit amet, consectetur adipiscing elit.</p>\n</div></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "urn:oid:1.2.208.176.2.1",
              "code" : "NPU01933",
              "display" : "B—Eosinophilocytter; antalk. = ? × 10^9/L"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/BrunoElmerPatient"
        },
        "effectiveDateTime" : "2025-08-07T14:36:08+02:00",
        "valueQuantity" : {
          "value" : 0.11,
          "unit" : "10^9/L"
        },
        "interpretation" : [
          {
            "coding" : [
              {
                "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-interpretation-codes",
                "code" : "NI",
                "display" : "Not Interpreted"
              }
            ]
          }
        ],
        "note" : [
          {
            "text" : "Lorem Ipsum dolor sit amet, consectetur adipiscing elit."
          }
        ]
      }
    }
  ]
}

```
