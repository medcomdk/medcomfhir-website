# Home - Danish XDS Documents profiles v1.0.0-trial-use-3

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://medcomfhir.dk/ig/xdsdocuments/ImplementationGuide/medcom.fhir.dk.xdsdocuments | *Version*:1.0.0-trial-use-3 |
| Draft as of 2026-07-30 | *Computable Name*:MedComXDSDocuments |

