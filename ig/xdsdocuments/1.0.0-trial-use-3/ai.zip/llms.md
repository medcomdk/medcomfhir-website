# medcom.fhir.dk.xdsdocuments#1.0.0-trial-use-3: Danish XDS Documents profiles

## Pages

* [Home](index.md)
* [Producer of FHIR resources - Testing](ActorDefinition-ProducerActor-testing.md)
* [Producer of FHIR resources - TTL Representation](ActorDefinition-ProducerActor.ttl.md)
* [Producer of FHIR resources](ActorDefinition-ProducerActor.md)
* [Downloads](downloads.md)
* [Producer of FHIR resources - XML Representation](ActorDefinition-ProducerActor.xml.md)
* [Artifacts Summary](artifacts.md)
* [Profiles](profiles.md)
* [](ActorDefinition-ProducerActor.change.history.md)
* [Dependencies](dependencies.md)
* [Producer of FHIR resources - JSON Representation](ActorDefinition-ProducerActor.json.md)
* [Extensions](extensions.md)

## Resources

### Resource Profiles

* [HomeCareObservationDocumentReference](StructureDefinition-homecare-observation-documentreference.md)
* [MedComConditionListDocumentReference](StructureDefinition-medcom-conditionlist-documentreference.md)
* [MedComContainedDocumentReference](StructureDefinition-medcom-contained-documentreference.md)
* [MedComDocumentOrganization](StructureDefinition-medcom-document-organization.md)
* [MedComDocumentPatient](StructureDefinition-medcom-document-patient.md)
* [MedComDocumentPractitioner](StructureDefinition-medcom-document-practitioner.md)
* [MedComDocumentPractitionerRole](StructureDefinition-medcom-document-practitionerrole.md)

### Extensions

* [MedCom Document HomeCommunityID](StructureDefinition-medcom-document-homecommunityid-extension.md)

### ImplementationGuides

* [Danish XDS Documents profiles](index.md)

### Examples

* [ProducerActor (Basic)](Basic-ProducerActor.md)
* [16002002-ac41-45de-ad6b-eb02b098e859 (DocumentReference)](DocumentReference-16002002-ac41-45de-ad6b-eb02b098e859.md)
* [4daf727f-f116-4e49-ad31-4018f0cc638a (DocumentReference)](DocumentReference-4daf727f-f116-4e49-ad31-4018f0cc638a.md)
