# medcom.fhir.dk.xdsdocuments#0.1.0-homecareobservation-draft: Danish XDS Documents profiles

## Pages

* [Home](index.md)
* [Extensions](extensions.md)
* [Profiles](profiles.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [MedComHCOFormatCodeCS](CodeSystem-MedComHCOFormatCodeCS.md)

### ValueSets

* [MedComHCOFormatCodeVS](ValueSet-MedComHCOFormatCodeVS.md)
* [MedComHCOTypeCodeVS](ValueSet-MedComHCOTypeCodeVS.md)

### Resource Profiles

* [HomeCareObservationDocumentReference](StructureDefinition-homecare-observation-documentreference.md)

### ImplementationGuides

* [Danish XDS Documents profiles](index.md)
