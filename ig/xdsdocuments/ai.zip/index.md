# Home - Danish XDS Documents profiles v1.0.0-trial-use-1

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://medcomfhir.dk/ig/xdsdocuments/ImplementationGuide/medcom.fhir.dk.xdsdocuments | *Version*:1.0.0-trial-use-1 |
| Draft as of 2026-06-01 | *Computable Name*:MedComXDSDocuments |

