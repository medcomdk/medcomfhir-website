# Producer of FHIR resources - Danish XDS Documents profiles v1.0.0-trial-use-2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Producer of FHIR resources**

## ActorDefinition: Producer of FHIR resources 

| | |
| :--- | :--- |
| *Official URL*:http://medcomfhir.dk/ig/xdsdocuments/ActorDefinition/ProducerActor | *Version*:1.0.0-trial-use-2 |
| Active as of 2026-06-17 | *Computable Name*:Producer of FHIR resources |

 
The system that creates the FHIR resources 

