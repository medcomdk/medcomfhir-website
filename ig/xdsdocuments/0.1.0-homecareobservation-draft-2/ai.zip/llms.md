# medcom.fhir.dk.xdsdocuments#0.1.0-homecareobservation-draft-2: Danish XDS Documents profiles

## Pages

* [Home](index.md)
* [Extensions](extensions.md)
* [Profiles](profiles.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [MedComHCOFormatCodeCS](CodeSystem-MedComHCOFormatCodeCS.md)
* [MedComHCOTypeCodeCS](CodeSystem-MedComHCOTypeCodeCS.md)

### ValueSets

* [MedComHCOFormatCodeVS](ValueSet-MedComHCOFormatCodeVS.md)
* [MedComHCOTypeCodeVS](ValueSet-MedComHCOTypeCodeVS.md)

### Resource Profiles

* [HomeCareObservationDocumentReference](StructureDefinition-homecare-observation-documentreference.md)

### ImplementationGuides

* [Danish XDS Documents profiles](index.md)

### Examples

* [16002002-ac41-45de-ad6b-eb02b098e859 (DocumentReference)](DocumentReference-16002002-ac41-45de-ad6b-eb02b098e859.md)
