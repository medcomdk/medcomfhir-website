# Producer of FHIR resources - JSON Representation - DK MedCom EKG v1.0.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Producer of FHIR resources**

## : Producer of FHIR resources - JSON Representation

| |
| :--- |
| Active as of 2026-01-28 |

[Raw json](ActorDefinition-ProducerActor.json) | [Download](ActorDefinition-ProducerActor.json)

