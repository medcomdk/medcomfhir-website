# Producer of FHIR resources - Testing - DK MedCom EKG v1.0.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Producer of FHIR resources**

## ActorDefinition: Producer of FHIR resources - Testing 

| |
| :--- |
| Active as of 2026-01-28 |

### Test Plans

**No test plans are currently available for the ActorDefinition.**

### Test Scripts

**No test scripts are currently available for the ActorDefinition.**

