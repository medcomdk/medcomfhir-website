# Producer of FHIR resources - XML Representation - DK MedCom EKG v1.0.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Producer of FHIR resources**

## : Producer of FHIR resources - XML Representation

| |
| :--- |
| Active as of 2026-01-28 |

[Raw xml](ActorDefinition-ProducerActor.xml) | [Download](ActorDefinition-ProducerActor.xml)

