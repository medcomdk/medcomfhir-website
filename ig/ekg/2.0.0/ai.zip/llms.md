# medcom.fhir.dk.ekg#2.0.0: DK MedCom EKG

## Pages

* [Home](index.md)
* [Producer of FHIR resources - XML Representation](ActorDefinition-ProducerActor.xml.md)
* [Producer of FHIR resources - Testing](ActorDefinition-ProducerActor-testing.md)
* [Examples](examples.md)
* [Profiles](profiles.md)
* [Producer of FHIR resources - JSON Representation](ActorDefinition-ProducerActor.json.md)
* [Producer of FHIR resources - TTL Representation](ActorDefinition-ProducerActor.ttl.md)
* [Dependencies](dependencies.md)
* [Downloads](downloads.md)
* [Producer of FHIR resources](ActorDefinition-ProducerActor.md)
* [Artifacts Summary](artifacts.md)
* [](ActorDefinition-ProducerActor.change.history.md)

## Resources

### Resource Profiles

* [MedComEkgRecordingBundle](StructureDefinition-medcom-ekg-recording-bundle.md)
* [MedComEkgRecordingComposition](StructureDefinition-medcom-ekg-recording-composition.md)
* [MedComEkgRecordingObservation](StructureDefinition-medcom-ekg-recording-observation.md)

### ImplementationGuides

* [DK MedCom EKG](index.md)

### Examples

* [ProducerActor (Basic)](Basic-ProducerActor.md)
* [0a74554f-ded3-4bc7-bef1-535699565c5a (Bundle)](Bundle-0a74554f-ded3-4bc7-bef1-535699565c5a.md)
* [Elektrokardiogram-12-aflednings (Composition)](Composition-384ca229-c562-4a26-a035-c0c38108e036.md)
* [ef810168-ee8c-4f14-9012-6aff6c1d86e7 (Observation)](Observation-ef810168-ee8c-4f14-9012-6aff6c1d86e7.md)
* [Lægerne Hasseris Bymidte (Organization)](Organization-f8d0eb07-5336-4005-9081-b065f9a82663.md)
* [379ebb53-11e3-42ac-b9db-0bad0ece46d1 (Patient)](Patient-379ebb53-11e3-42ac-b9db-0bad0ece46d1.md)
* [48ed6310-3095-44da-9e34-d1cd6bd830c9 (Practitioner)](Practitioner-48ed6310-3095-44da-9e34-d1cd6bd830c9.md)
* [bb6fa4e1-f8b1-4bf4-b77e-bb03b2cc9820 (PractitionerRole)](PractitionerRole-bb6fa4e1-f8b1-4bf4-b77e-bb03b2cc9820.md)
