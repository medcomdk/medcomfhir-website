# medcom.fhir.dk.messaging#4.0.2: DK MedCom Messaging

## Pages

* [Home](index.md)
* [Producer of FHIR resources - JSON Representation](ActorDefinition-ProducerActor.json.md)
* [Producer of FHIR resources - Testing](ActorDefinition-ProducerActor-testing.md)
* [Producer of FHIR resources](ActorDefinition-ProducerActor.md)
* [Artifacts Summary](artifacts.md)
* [Dependencies](dependencies.md)
* [Extensions](extensions.md)
* [Downloads](downloads.md)
* [Profiles](profiles.md)
* [](ActorDefinition-ProducerActor.change.history.md)
* [Producer of FHIR resources - TTL Representation](ActorDefinition-ProducerActor.ttl.md)
* [Producer of FHIR resources - XML Representation](ActorDefinition-ProducerActor.xml.md)

## Resources

### Resource Profiles

* [MedComMessagingMessage](StructureDefinition-medcom-messaging-message.md)
* [MedComMessagingMessageHeader](StructureDefinition-medcom-messaging-messageHeader.md)
* [MedComMessagingOrganization](StructureDefinition-medcom-messaging-organization.md)
* [MedComMessagingProvenance](StructureDefinition-medcom-messaging-provenance.md)
* [MedComCoreProducerOrganization](StructureDefinition-medcom-producer-organization.md)
* [MedComMessagingRequesterOrganization](StructureDefinition-medcom-requesterorganization.md)

### Extensions

* [MedComDestinationUseExtension](StructureDefinition-medcom-messaging-destinationUseExtension.md)

### ImplementationGuides

* [DK MedCom Messaging](index.md)

### Examples

* [ProducerActor (Basic)](Basic-ProducerActor.md)
* [eb26be85-fdb7-454d-a980-95cba6d1745b (Bundle)](Bundle-eb26be85-fdb7-454d-a980-95cba6d1745b.md)
* [3881874e-2042-4a00-aee8-23512799f512 (MessageHeader)](MessageHeader-3881874e-2042-4a00-aee8-23512799f512.md)
* [42c01434-8feb-11ec-b909-0242ac120002 (MessageHeader)](MessageHeader-42c01434-8feb-11ec-b909-0242ac120002.md)
* [cb0b2ef0-8feb-11ec-b909-0242ac120002 (MessageHeader)](MessageHeader-cb0b2ef0-8feb-11ec-b909-0242ac120002.md)
* [d28b9cb4-8feb-11ec-b909-0242ac120002 (MessageHeader)](MessageHeader-d28b9cb4-8feb-11ec-b909-0242ac120002.md)
* [Aros Burn Center (Organization)](Organization-12ee0dde-a672-462f-820d-5efe832d73c9.md)
* [Skødstrup Lægepraksis (Organization)](Organization-42541447-b58c-4a1a-9514-02b80494bbd3.md)
* [Receiver Organization (Organization)](Organization-74cdf292-abf3-4f5f-80ea-60a48013ff6d.md)
* [bf839e87-4e44-4977-b38e-92b5a6f187b5 (Organization)](Organization-bf839e87-4e44-4977-b38e-92b5a6f187b5.md)
* [Sender Organization (Organization)](Organization-d7056980-a8b2-42aa-8a0e-c1fc85d1f40d.md)
* [Pleje og Rehabilitering (Organization)](Organization-ef5cb9a6-835f-4d18-a34e-179c578b9a2a.md)
* [733cef33-3626-422b-955d-d506aaa65fe1 (Patient)](Patient-733cef33-3626-422b-955d-d506aaa65fe1.md)
* [58c811a5-4082-44eb-9d66-ccbb112d4973 (Practitioner)](Practitioner-58c811a5-4082-44eb-9d66-ccbb112d4973.md)
* [9c284936-5454-4116-95fc-3c8eeeed2400 (Provenance)](Provenance-9c284936-5454-4116-95fc-3c8eeeed2400.md)
