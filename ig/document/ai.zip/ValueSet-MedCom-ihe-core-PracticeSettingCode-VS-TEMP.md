# IHE PracticeSettingCode_TEMP - DK MedCom Document v2.0.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **IHE PracticeSettingCode_TEMP**

## ValueSet: IHE PracticeSettingCode_TEMP 

| | |
| :--- | :--- |
| *Official URL*:http://medcomfhir.dk/ig/document/ValueSet/MedCom-ihe-core-PracticeSettingCode-VS-TEMP | *Version*:2.0.2 |
| Active as of 2024-06-20 | *Computable Name*:MedComIHE_CorePracticeSettingCode_TEMP |

 
_TEMP Values used for the document metadata attribute practiceSettingCode, which is an attribute specifying the clinical specialty where the act that resulted in the document was performed (e.g., Family Practice, Laboratory, Radiology). The value set is based on a subset of the code list from the SOR lookup table 'SOR-Kliniske specialer' (https://sor.sum.dsdn.dk/lookupdata/#clinical_speciality, accessable on Sundhedsdatanettet (SDN)), which is based on SNOMED codes. 

 **References** 

* [MedComContainedDocumentReference](StructureDefinition-medcom-contained-documentreference.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "MedCom-ihe-core-PracticeSettingCode-VS-TEMP",
  "url" : "http://medcomfhir.dk/ig/document/ValueSet/MedCom-ihe-core-PracticeSettingCode-VS-TEMP",
  "version" : "2.0.2",
  "name" : "MedComIHE_CorePracticeSettingCode_TEMP",
  "title" : "IHE PracticeSettingCode_TEMP",
  "status" : "active",
  "experimental" : false,
  "date" : "2024-06-20",
  "publisher" : "MedCom",
  "contact" : [
    {
      "name" : "MedCom",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://www.medcom.dk"
        },
        {
          "system" : "email",
          "value" : "fhir@medcom.dk"
        }
      ]
    }
  ],
  "description" : "_TEMP Values used for the document metadata attribute practiceSettingCode, which is an attribute specifying the clinical specialty where the act that resulted in the document was performed (e.g., Family Practice, Laboratory, Radiology). The value set is based on a subset of the code list from the SOR lookup table 'SOR-Kliniske specialer' (https://sor.sum.dsdn.dk/lookupdata/#clinical_speciality, accessable on Sundhedsdatanettet (SDN)), which is based on SNOMED codes. ",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "DK",
          "display" : "Denmark"
        }
      ]
    }
  ],
  "compose" : {
    "include" : [
      {
        "system" : "http://snomed.info/sct",
        "version" : "http://snomed.info/sct/554471000005108",
        "concept" : [
          {
            "code" : "773568002",
            "display" : "akutmedicin"
          },
          {
            "code" : "408443003",
            "display" : "almen medicin"
          },
          {
            "code" : "394577000",
            "display" : "anæstesiologi"
          },
          {
            "code" : "394821009",
            "display" : "arbejdsmedicin"
          },
          {
            "code" : "394588006",
            "display" : "børne_ og ungdomspsykiatri"
          },
          {
            "code" : "394582007",
            "display" : "dermato_venerologi"
          },
          {
            "code" : "394914008",
            "display" : "diagnostisk radiologi"
          },
          {
            "code" : "394583002",
            "display" : "endokrinologi"
          },
          {
            "code" : "394811001",
            "display" : "geriatri"
          },
          {
            "code" : "394585009",
            "display" : "gynækologi og obstetrik"
          },
          {
            "code" : "408472002",
            "display" : "hepatologi"
          },
          {
            "code" : "394803006",
            "display" : "hæmatologi"
          },
          {
            "code" : "394807007",
            "display" : "infektionsmedicin"
          },
          {
            "code" : "419192003",
            "display" : "intern medicin"
          },
          {
            "code" : "394579002",
            "display" : "kardiologi"
          },
          {
            "code" : "408463005",
            "display" : "karkirurgi"
          },
          {
            "code" : "394609007",
            "display" : "kirurgi"
          },
          {
            "code" : "551411000005104",
            "display" : "kirurgisk gastroenterologi"
          },
          {
            "code" : "394596001",
            "display" : "klinisk biokemi"
          },
          {
            "code" : "394600006",
            "display" : "klinisk farmakologi"
          },
          {
            "code" : "394601005",
            "display" : "klinisk fysiologi og nuklearmedicin (snomed: klinisk fysiologi)"
          },
          {
            "code" : "394580004",
            "display" : "klinisk genetik"
          },
          {
            "code" : "421661004",
            "display" : "klinisk immunologi"
          },
          {
            "code" : "408454008",
            "display" : "klinisk mikrobiologi"
          },
          {
            "code" : "394809005",
            "display" : "klinisk neurofysiologi"
          },
          {
            "code" : "394592004",
            "display" : "klinisk onkologi"
          },
          {
            "code" : "418112009",
            "display" : "lungesygdomme"
          },
          {
            "code" : "394805004",
            "display" : "medicinsk allergologi"
          },
          {
            "code" : "394584008",
            "display" : "medicinsk gastroenterologi"
          },
          {
            "code" : "394589003",
            "display" : "nefrologi"
          },
          {
            "code" : "394610002",
            "display" : "neurokirurgi"
          },
          {
            "code" : "394591006",
            "display" : "neurologi"
          },
          {
            "code" : "394812008",
            "display" : "odontologi (snomed: odontologiske specialer)"
          },
          {
            "code" : "394594003",
            "display" : "oftalmologi"
          },
          {
            "code" : "394608004",
            "display" : "ortodonti"
          },
          {
            "code" : "394801008",
            "display" : "ortopædisk kirurgi"
          },
          {
            "code" : "394604002",
            "display" : "oto_rhino_laryngologi"
          },
          {
            "code" : "394915009",
            "display" : "patologisk anatomi og cytologi"
          },
          {
            "code" : "394611003",
            "display" : "plastikkirurgi"
          },
          {
            "code" : "394587001",
            "display" : "psykiatri"
          },
          {
            "code" : "394537008",
            "display" : "pædiatri"
          },
          {
            "code" : "394810000",
            "display" : "reumatologi"
          },
          {
            "code" : "394581000",
            "display" : "samfundsmedicin"
          },
          {
            "code" : "394605001",
            "display" : "tand_, mund_ og kæbekirurgi"
          },
          {
            "code" : "394603008",
            "display" : "thoraxkirurgi"
          },
          {
            "code" : "408448007",
            "display" : "tropemedicin"
          },
          {
            "code" : "394612005",
            "display" : "urologi"
          },
          {
            "code" : "658171000005102",
            "display" : "hjemmepleje"
          },
          {
            "code" : "658161000005107",
            "display" : "hjemmesygepleje"
          },
          {
            "code" : "658151000005105",
            "display" : "sundhedsfremme og forebyggelse"
          },
          {
            "code" : "658191000005101",
            "display" : "sundhedspleje"
          },
          {
            "code" : "658201000005103",
            "display" : "kommunal tandpleje"
          },
          {
            "code" : "658141000005108",
            "display" : "genoptræning efter hospitalsophold"
          },
          {
            "code" : "658181000005104",
            "display" : "hjælpemiddelområdet"
          }
        ]
      }
    ]
  }
}

```
