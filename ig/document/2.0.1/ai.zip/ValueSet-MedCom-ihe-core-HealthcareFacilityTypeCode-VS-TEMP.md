# IHE HealthcareFacilityTypeCode_TEMP - DK MedCom Document v2.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **IHE HealthcareFacilityTypeCode_TEMP**

## ValueSet: IHE HealthcareFacilityTypeCode_TEMP 

| | |
| :--- | :--- |
| *Official URL*:http://medcomfhir.dk/ig/document/ValueSet/MedCom-ihe-core-HealthcareFacilityTypeCode-VS-TEMP | *Version*:2.0.1 |
| Active as of 2024-01-19 | *Computable Name*:MedComIHE_CoreHealthcareFacilityTypeCode_TEMP |

 
_TEMP Value set for healthcare facility type code represents the type of organizational setting of the clinical encounter during which the documented act occurred. 

 **References** 

* [MedComContainedDocumentReference](StructureDefinition-medcom-contained-documentreference.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "MedCom-ihe-core-HealthcareFacilityTypeCode-VS-TEMP",
  "url" : "http://medcomfhir.dk/ig/document/ValueSet/MedCom-ihe-core-HealthcareFacilityTypeCode-VS-TEMP",
  "version" : "2.0.1",
  "name" : "MedComIHE_CoreHealthcareFacilityTypeCode_TEMP",
  "title" : "IHE HealthcareFacilityTypeCode_TEMP",
  "status" : "active",
  "experimental" : false,
  "date" : "2024-01-19",
  "publisher" : "MedCom",
  "contact" : [
    {
      "name" : "MedCom",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://www.medcom.dk"
        },
        {
          "system" : "email",
          "value" : "fhir@medcom.dk"
        }
      ]
    }
  ],
  "description" : "_TEMP Value set for healthcare facility type code represents the type of organizational setting of the clinical encounter during which the documented act occurred.",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "DK",
          "display" : "Denmark"
        }
      ]
    }
  ],
  "compose" : {
    "include" : [
      {
        "system" : "http://snomed.info/sct",
        "version" : "http://snomed.info/sct/554471000005108",
        "concept" : [
          {
            "code" : "557511000005107",
            "display" : "akupunkturklinik"
          },
          {
            "code" : "550871000005101",
            "display" : "akutmodtageenhed"
          },
          {
            "code" : "394761003",
            "display" : "almen lægepraksis"
          },
          {
            "code" : "264372000",
            "display" : "apotek"
          },
          {
            "code" : "557501000005109",
            "display" : "apoteksfilial"
          },
          {
            "code" : "554851000005102",
            "display" : "asylcenter"
          },
          {
            "code" : "557531000005103",
            "display" : "bandagistklinik"
          },
          {
            "code" : "20078004",
            "display" : "behandlingscenter for stofmisbrugere"
          },
          {
            "code" : "722173008",
            "display" : "behandlingsenhed i fængsel eller arresthus"
          },
          {
            "code" : "309964003",
            "display" : "billeddiagnostisk enhed"
          },
          {
            "code" : "554221000005108",
            "display" : "bosted"
          },
          {
            "code" : "56781000005109",
            "display" : "center for misbrugsbehandling"
          },
          {
            "code" : "557881000005104",
            "display" : "COVID-19-testenhed"
          },
          {
            "code" : "554031000005103",
            "display" : "diætistklinik"
          },
          {
            "code" : "557891000005101",
            "display" : "enhed for aktivitetstilbud"
          },
          {
            "code" : "546821000005103",
            "display" : "ergoterapiklinik"
          },
          {
            "code" : "702871004",
            "display" : "fertilitetsklinik"
          },
          {
            "code" : "554061000005105",
            "display" : "fodterapeutklinik"
          },
          {
            "code" : "557901000005102",
            "display" : "forebyggende hjemmebesøgsenhed"
          },
          {
            "code" : "550861000005106",
            "display" : "fysioterapi- og ergoterapiklinik"
          },
          {
            "code" : "547011000005103",
            "display" : "fysioterapiklinik"
          },
          {
            "code" : "546811000005109",
            "display" : "genoptræningsenhed"
          },
          {
            "code" : "554881000005108",
            "display" : "handicap- og psykiatrienhed"
          },
          {
            "code" : "554861000005100",
            "display" : "handicapenhed"
          },
          {
            "code" : "554821000005109",
            "display" : "hjemmeplejeenhed"
          },
          {
            "code" : "550621000005101",
            "display" : "hjemmesygeplejeenhed"
          },
          {
            "code" : "284546000",
            "display" : "hospice"
          },
          {
            "code" : "22232009",
            "display" : "hospital"
          },
          {
            "code" : "702824005",
            "display" : "hørecenter"
          },
          {
            "code" : "309904001",
            "display" : "intensivenhed"
          },
          {
            "code" : "557591000005104",
            "display" : "internetbaseret sundhedsydelse"
          },
          {
            "code" : "554411000005101",
            "display" : "jobcenter"
          },
          {
            "code" : "550631000005103",
            "display" : "jordemoderklinik"
          },
          {
            "code" : "550641000005106",
            "display" : "kiropraktorklinik"
          },
          {
            "code" : "557521000005101",
            "display" : "klinik for alternativ behandling"
          },
          {
            "code" : "550851000005109",
            "display" : "klinisk enhed"
          },
          {
            "code" : "547211000005108",
            "display" : "kommune"
          },
          {
            "code" : "557561000005105",
            "display" : "konsulentvirksomhed"
          },
          {
            "code" : "557541000005106",
            "display" : "kosmetisk klinik"
          },
          {
            "code" : "550651000005108",
            "display" : "lægelaboratorium"
          },
          {
            "code" : "550661000005105",
            "display" : "lægevagt"
          },
          {
            "code" : "551611000005102",
            "display" : "operationsgang"
          },
          {
            "code" : "557581000005102",
            "display" : "optikervirksomhed"
          },
          {
            "code" : "557671000005101",
            "display" : "osteopatiklinik"
          },
          {
            "code" : "309939001",
            "display" : "palliativ enhed"
          },
          {
            "code" : "42665001",
            "display" : "plejehjem"
          },
          {
            "code" : "550891000005100",
            "display" : "privat"
          },
          {
            "code" : "554211000005102",
            "display" : "præhospitalsenhed"
          },
          {
            "code" : "554871000005105",
            "display" : "psykiatrienhed"
          },
          {
            "code" : "550711000005101",
            "display" : "psykologisk rådgivningsklinik"
          },
          {
            "code" : "556841000005105",
            "display" : "pædagogisk psykologisk rådgivning (PPR)"
          },
          {
            "code" : "702916001",
            "display" : "rehabiliteringsenhed"
          },
          {
            "code" : "225728007",
            "display" : "skadestue"
          },
          {
            "code" : "550671000005100",
            "display" : "speciallægepraksis"
          },
          {
            "code" : "264361005",
            "display" : "sundhedscenter"
          },
          {
            "code" : "554041000005106",
            "display" : "sundhedsforvaltning"
          },
          {
            "code" : "554021000005101",
            "display" : "sundhedsplejen"
          },
          {
            "code" : "554071000005100",
            "display" : "sygehusapotek"
          },
          {
            "code" : "703069008",
            "display" : "sygeplejeklinik"
          },
          {
            "code" : "550681000005102",
            "display" : "tandlægepraksis"
          },
          {
            "code" : "550691000005104",
            "display" : "tandplejeklinik"
          },
          {
            "code" : "550701000005104",
            "display" : "tandteknisk klinik"
          },
          {
            "code" : "554231000005106",
            "display" : "vaccinationsklinik"
          },
          {
            "code" : "554051000005108",
            "display" : "zoneterapiklinik"
          },
          {
            "code" : "550811000005108",
            "display" : "administrativ enhed"
          }
        ]
      }
    ]
  }
}

```
