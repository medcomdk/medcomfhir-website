# medcom.fhir.dk.document#2.0.1: DK MedCom Document

## Pages

* [Home](index.md)
* [Producer of FHIR resources - JSON Representation](ActorDefinition-ProducerActor.json.md)
* [Producer of FHIR resources - Testing](ActorDefinition-ProducerActor-testing.md)
* [Producer of FHIR resources](ActorDefinition-ProducerActor.md)
* [Artifacts Summary](artifacts.md)
* [Dependencies](dependencies.md)
* [Unstructuredclinicalcontent](unstructuredclinicalcontent.md)
* [Extensions](extensions.md)
* [Downloads](downloads.md)
* [Profiles](profiles.md)
* [](ActorDefinition-ProducerActor.change.history.md)
* [Producer of FHIR resources - TTL Representation](ActorDefinition-ProducerActor.ttl.md)
* [Producer of FHIR resources - XML Representation](ActorDefinition-ProducerActor.xml.md)

## Resources

### CodeSystems

* [DK IHE ClassCode_TEMP](CodeSystem-MedCom-ihe-classcode-CS-TEMP.md)
* [DK IHE FormatCode_TEMP](CodeSystem-MedCom-ihe-formatcode-CS-TEMP.md)
* [_TEMP IHE XDS Affinity Domain](CodeSystem-MedCom-ihe-homeCommunityId-CS-TEMP.md)
* [MedCom Message Codes_TEMP](CodeSystem-MedCom-message-codes-CS-TEMP.md)

### ValueSets

* [IHE HealthcareFacilityTypeCode_TEMP](ValueSet-MedCom-ihe-core-HealthcareFacilityTypeCode-VS-TEMP.md)
* [IHE PracticeSettingCode_TEMP](ValueSet-MedCom-ihe-core-PracticeSettingCode-VS-TEMP.md)
* [IHE ClassCode_TEMP](ValueSet-MedCom-ihe-core-classcode-VS-TEMP.md)
* [IHE ConfidentialityCode_TEMP](ValueSet-MedCom-ihe-core-confidentialitycode-VS-TEMP.md)
* [IHE FormatCode_TEMP](ValueSet-MedCom-ihe-core-formatcode-VS-TEMP.md)
* [_TEMP IHE HomeCommunityId](ValueSet-MedCom-ihe-core-homeCommunityId-VS-TEMP.md)
* [IHE LanguageCode_TEMP](ValueSet-MedCom-ihe-core-languagecode-VS-TEMP.md)
* [IHE MimeType_TEMP](ValueSet-MedCom-ihe-core-mimetype-VS-TEMP.md)
* [IHE TypeCode_TEMP](ValueSet-MedCom-ihe-core-typecode-VS-TEMP.md)

### Resource Profiles

* [MedComContainedDocumentReference](StructureDefinition-medcom-contained-documentreference.md)
* [MedComDocumentBundle](StructureDefinition-medcom-document-bundle.md)
* [MedComDocumentCareTeam](StructureDefinition-medcom-document-careteam.md)
* [MedComDocumentComposition](StructureDefinition-medcom-document-composition.md)
* [MedComDocumentObservation](StructureDefinition-medcom-document-observation.md)
* [MedComDocumentOrganization](StructureDefinition-medcom-document-organization.md)
* [MedComDocumentPatient](StructureDefinition-medcom-document-patient.md)
* [MedComDocumentPractitioner](StructureDefinition-medcom-document-practitioner.md)
* [MedComDocumentPractitionerRole](StructureDefinition-medcom-document-practitionerrole.md)

### Extensions

* [MedCom Document HomeCommunityID](StructureDefinition-medcom-document-homecommunityid-extension.md)
* [MedCom XDS Version ID extension](StructureDefinition-medcom-document-version-id-extension.md)

### ImplementationGuides

* [DK MedCom Document](index.md)

### Examples

* [ProducerActor (Basic)](Basic-ProducerActor.md)
* [0a74554f-ded3-4bc7-bef1-535699565c5b (Bundle)](Bundle-0a74554f-ded3-4bc7-bef1-535699565c5b.md)
* [Elektrokardiogram-12-aflednings (Composition)](Composition-384ca229-c562-4a26-a035-c0c38108e037.md)
* [ef810168-ee8c-4f14-9012-6aff6c1d86e7 (Observation)](Observation-ef810168-ee8c-4f14-9012-6aff6c1d86e7.md)
* [Lægerne Hasseris Bymidte (Organization)](Organization-8fa7df76-bec2-4fe2-9a44-750030a0eda0.md)
* [Lægerne Hasseris Bymidte (Organization)](Organization-f8d0eb07-5336-4005-9081-b065f9a82663.md)
* [37628912-7816-47a3-acd8-396b610be142 (Patient)](Patient-37628912-7816-47a3-acd8-396b610be142.md)
* [379ebb53-11e3-42ac-b9db-0bad0ece46d1 (Patient)](Patient-379ebb53-11e3-42ac-b9db-0bad0ece46d1.md)
* [42cb9200-f421-4d08-8391-7d51a2503cb4 (Practitioner)](Practitioner-42cb9200-f421-4d08-8391-7d51a2503cb4.md)
* [48ed6310-3095-44da-9e34-d1cd6bd830c9 (Practitioner)](Practitioner-48ed6310-3095-44da-9e34-d1cd6bd830c9.md)
* [bb6fa4e1-f8b1-4bf4-b77e-bb03b2cc9820 (PractitionerRole)](PractitionerRole-bb6fa4e1-f8b1-4bf4-b77e-bb03b2cc9820.md)
