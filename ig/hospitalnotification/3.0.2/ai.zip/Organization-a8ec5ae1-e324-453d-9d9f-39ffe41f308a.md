# Receiver organization - Plejecenter Herlev. - DK MedCom HospitalNotification v3.0.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Receiver organization - Plejecenter Herlev.**

## Organization: Receiver organization - Plejecenter Herlev.

Profile: [MedComMessagingOrganization](http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-organization.html)

**identifier**: `https://www.gs1.org/gln`/5790001348120, `urn:oid:1.2.208.176.1.1`/953741000016009

**name**: Plejecenter Herlev



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "a8ec5ae1-e324-453d-9d9f-39ffe41f308a",
  "meta" : {
    "profile" : [
      "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"
    ]
  },
  "identifier" : [
    {
      "system" : "https://www.gs1.org/gln",
      "value" : "5790001348120"
    },
    {
      "system" : "urn:oid:1.2.208.176.1.1",
      "value" : "953741000016009"
    }
  ],
  "name" : "Plejecenter Herlev"
}

```
