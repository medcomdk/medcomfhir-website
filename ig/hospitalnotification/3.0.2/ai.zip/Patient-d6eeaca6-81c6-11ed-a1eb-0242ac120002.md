# Patient - Bruno Test Elmer - DK MedCom HospitalNotification v3.0.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Patient - Bruno Test Elmer**

## Patient: Patient - Bruno Test Elmer

Profile: [MedComCorePatient](http://medcomfhir.dk/ig/core/2.3.0/StructureDefinition-medcom-core-patient.html)

Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)

-------



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "d6eeaca6-81c6-11ed-a1eb-0242ac120002",
  "meta" : {
    "profile" : [
      "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-patient"
    ]
  },
  "identifier" : [
    {
      "system" : "urn:oid:1.2.208.176.1.2",
      "value" : "2509479989"
    }
  ],
  "name" : [
    {
      "use" : "official",
      "family" : "Elmer"
    }
  ]
}

```
