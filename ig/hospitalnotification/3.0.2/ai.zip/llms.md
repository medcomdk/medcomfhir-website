# medcom.fhir.dk.hospitalnotification#3.0.2: DK MedCom HospitalNotification

## Pages

* [Home](index.md)
* [Profiles](profiles.md)
* [Extensions](extensions.md)
* [Artifacts Summary](artifacts.md)
* [Examples](examples.md)
* [Downloads](downloads.md)

## Resources

### Resource Profiles

* [MedComHospitalNotificationEncounter](StructureDefinition-medcom-hospitalNotification-encounter.md)
* [MedComHospitalNotificationMessage](StructureDefinition-medcom-hospitalNotification-message.md)
* [MedComHospitalNotificationMessageHeader](StructureDefinition-medcom-hospitalNotification-messageHeader.md)

### Extensions

* [MedComHospitalNotificationLeavePeriodExtension](StructureDefinition-medcom-hospitalnotifiation-leave-period-extension.md)
* [MedComReportOfAdmissionExtension](StructureDefinition-medcom-messaging-reportOfAdmissionExtension.md)
* [MedComReportOfAdmissionRecipientExtension](StructureDefinition-medcom-messaging-reportOfAdmissionRecipientExtension.md)

### ImplementationGuides

* [DK MedCom HospitalNotification](index.md)

### Organizations

* [Hjerteafdelingen på Herlev og Gentofte hospital](Organization-0465ec66-81d2-11ed-a1eb-0242ac120002.md)
* [Hjerteafdelingen på Herlev og Gentofte hospital](Organization-05266a00-81c7-11ed-a1eb-0242ac120002.md)
* [Plejecenter Herlev](Organization-103fbebe-81d1-11ed-a1eb-0242ac120002.md)
* [Hjerteafdelingen på Herlev og Gentofte hospital](Organization-1f5882b4-81d1-11ed-a1eb-0242ac120002.md)
* [Hjerteafdelingen på Herlev og Gentofte hospital](Organization-2565d3de-082e-4368-9160-4c719071026b.md)
* [Plejecenter Herlev](Organization-55ba5884-81ca-11ed-a1eb-0242ac120002.md)
* [Plejecenter Herlev](Organization-55eb90b8-81d2-11ed-a1eb-0242ac120002.md)
* [Hjerteafdelingen på Herlev og Gentofte hospital](Organization-5961ade8-81ca-11ed-a1eb-0242ac120002.md)
* [Hjerteafdelingen på Herlev og Gentofte hospital](Organization-66c12a92-81d2-11ed-a1eb-0242ac120002.md)
* [Plejecenter Herlev](Organization-753bdcba-81ce-11ed-a1eb-0242ac120002.md)
* [Plejecenter Herlev](Organization-7e692262-81cd-11ed-a1eb-0242ac120002.md)
* [Hjerteafdelingen på Herlev og Gentofte hospital](Organization-840b4046-81ce-11ed-a1eb-0242ac120002.md)
* [Plejecenter Herlev](Organization-8858e7e6-81c6-11ed-a1eb-0242ac120002.md)
* [Hjerteafdelingen på Herlev og Gentofte hospital](Organization-8d813af0-81cd-11ed-a1eb-0242ac120002.md)
* [Plejecenter Herlev](Organization-a39d4a04-81c8-11ed-a1eb-0242ac120002.md)
* [Plejecenter Herlev](Organization-a8ec5ae1-e324-453d-9d9f-39ffe41f308a.md)
* [Hjerteafdelingen på Herlev og Gentofte hospital](Organization-abb09e14-81c6-11ed-a1eb-0242ac120002.md)
* [Hjerteafdelingen på Herlev og Gentofte hospital](Organization-b79a7914-81c8-11ed-a1eb-0242ac120002.md)
* [Plejecenter Herlev](Organization-bea5b49e-81d2-11ed-a1eb-0242ac120002.md)
* [Hjerteafdelingen på Herlev og Gentofte hospital](Organization-cd72967c-81d2-11ed-a1eb-0242ac120002.md)
* [Plejecenter Herlev](Organization-e5682f5e-81d1-11ed-a1eb-0242ac120002.md)
* [Plejecenter Herlev](Organization-eefc2dfa-81c6-11ed-a1eb-0242ac120002.md)
* [Plejecenter Herlev](Organization-o4cdf292-abf3-4f5f-80ea-60a48013ff6d.md)
* [Hjerteafdelingen på Herlev og Gentofte hospital](Organization-o7056980-a8b2-42aa-8a0e-c1fc85d1f40d.md)
* [Hjertemedicinsk sengeafs. S103](Organization-of839e87-4e44-4977-b38e-92b5a6f187b5.md)

### Patients

* [384b4a58-81d2-11ed-a1eb-0242ac120002](Patient-384b4a58-81d2-11ed-a1eb-0242ac120002.md)
* [48393486-81c6-11ed-a1eb-0242ac120002](Patient-48393486-81c6-11ed-a1eb-0242ac120002.md)
* [519d5170-81ca-11ed-a1eb-0242ac120002](Patient-519d5170-81ca-11ed-a1eb-0242ac120002.md)
* [545fd5e6-a924-11ed-afa1-0242ac120002](Patient-545fd5e6-a924-11ed-afa1-0242ac120002.md)
* [6841b54e-81cd-11ed-a1eb-0242ac120002](Patient-6841b54e-81cd-11ed-a1eb-0242ac120002.md)
* [6c16f41e-81d1-11ed-a1eb-0242ac120002](Patient-6c16f41e-81d1-11ed-a1eb-0242ac120002.md)
* [97404d10-81c8-11ed-a1eb-0242ac120002](Patient-97404d10-81c8-11ed-a1eb-0242ac120002.md)
* [b00ea1c0-81d2-11ed-a1eb-0242ac120002](Patient-b00ea1c0-81d2-11ed-a1eb-0242ac120002.md)
* [d6eeaca6-81c6-11ed-a1eb-0242ac120002](Patient-d6eeaca6-81c6-11ed-a1eb-0242ac120002.md)
* [fdc1fc66-81d0-11ed-a1eb-0242ac120002](Patient-fdc1fc66-81d0-11ed-a1eb-0242ac120002.md)
* [t33cef33-3626-422b-955d-d506aaa65fe1](Patient-t33cef33-3626-422b-955d-d506aaa65fe1.md)
* [t82fb8a3-6725-41e2-a615-2b1cfcfe9931](Patient-t82fb8a3-6725-41e2-a615-2b1cfcfe9931.md)

### Provenances

* [1b2e59fe-d6d3-457c-9c5c-3de1711a8a0b](Provenance-1b2e59fe-d6d3-457c-9c5c-3de1711a8a0b.md)
* [4e9f2c26-9d9b-4239-ade6-e26c130e855e](Provenance-4e9f2c26-9d9b-4239-ade6-e26c130e855e.md)
* [543296c8-d01b-4fbb-b737-1b1d9630a052](Provenance-543296c8-d01b-4fbb-b737-1b1d9630a052.md)
* [8a3b783c-60b3-4d6b-ae90-f6ead50ecb1d](Provenance-8a3b783c-60b3-4d6b-ae90-f6ead50ecb1d.md)
* [9925ca91-62aa-40f0-8b6f-5afae2a36c67](Provenance-9925ca91-62aa-40f0-8b6f-5afae2a36c67.md)
* [9c2257be-2a91-4314-8577-6f1a69f7ab86](Provenance-9c2257be-2a91-4314-8577-6f1a69f7ab86.md)
* [9d4f53ed-7e4b-477c-8021-1424cf5e9b1e](Provenance-9d4f53ed-7e4b-477c-8021-1424cf5e9b1e.md)
* [a7cf3888-6f42-4e4d-929c-d2475d24fba0](Provenance-a7cf3888-6f42-4e4d-929c-d2475d24fba0.md)
* [b5f7de8c-957a-11ec-b909-0242ac120002](Provenance-b5f7de8c-957a-11ec-b909-0242ac120002.md)
* [c67ecb1c-957a-11ec-b909-0242ac120002](Provenance-c67ecb1c-957a-11ec-b909-0242ac120002.md)
* [ca506c7f-fec6-4711-9397-efb98b7233b6](Provenance-ca506c7f-fec6-4711-9397-efb98b7233b6.md)
* [dc421d0a-cded-470f-9a53-2ddba7583baa](Provenance-dc421d0a-cded-470f-9a53-2ddba7583baa.md)
* [dc7dd664-f588-4f82-963b-3a032759c5a9](Provenance-dc7dd664-f588-4f82-963b-3a032759c5a9.md)
* [e4db4939-7c60-4ac6-aefc-523f809ccba6](Provenance-e4db4939-7c60-4ac6-aefc-523f809ccba6.md)
* [f710698c-83eb-4c3e-81c8-fe8e40baf524](Provenance-f710698c-83eb-4c3e-81c8-fe8e40baf524.md)
* [fc7efe44-2708-49b2-becf-3eddd2fdef43](Provenance-fc7efe44-2708-49b2-becf-3eddd2fdef43.md)
* [g9942adb-197a-4e30-bec8-566e3a113efe](Provenance-g9942adb-197a-4e30-bec8-566e3a113efe.md)
* [h60bd482-9c47-43c5-9b77-1134eaa2d5f0](Provenance-h60bd482-9c47-43c5-9b77-1134eaa2d5f0.md)
* [ka776a3e-3eca-407b-9f81-b8c16f089874](Provenance-ka776a3e-3eca-407b-9f81-b8c16f089874.md)
* [l17de5f5-abb0-4701-93aa-6b0d7b4127bc](Provenance-l17de5f5-abb0-4701-93aa-6b0d7b4127bc.md)
* [m7cf3888-6f52-5e4d-939c-d2575d24fba0](Provenance-m7cf3888-6f52-5e4d-939c-d2575d24fba0.md)

### Examples

* [a5e5b880-c087-4055-b9ec-99108695f81d (Bundle)](Bundle-a5e5b880-c087-4055-b9ec-99108695f81d.md)
* [bfab3e80-9584-11ec-b909-0242ac120002 (Bundle)](Bundle-bfab3e80-9584-11ec-b909-0242ac120002.md)
* [c83671a4-9584-11ec-b909-0242ac120002 (Bundle)](Bundle-c83671a4-9584-11ec-b909-0242ac120002.md)
* [d3128d9b-cede-4c7f-8904-809eab322d7d (Bundle)](Bundle-d3128d9b-cede-4c7f-8904-809eab322d7d.md)
* [e94de8ee-bd94-475e-b454-b8fbbef8a685 (Bundle)](Bundle-e94de8ee-bd94-475e-b454-b8fbbef8a685.md)
* [f4aa42a4-86db-4e68-9b38-9dda0dfd5774 (Bundle)](Bundle-f4aa42a4-86db-4e68-9b38-9dda0dfd5774.md)
* [g099bbf3-3fca-4722-a248-bfe1aa956410 (Bundle)](Bundle-g099bbf3-3fca-4722-a248-bfe1aa956410.md)
* [h1c8e4a8-6b45-4669-94ad-2a99ad96bf03 (Bundle)](Bundle-h1c8e4a8-6b45-4669-94ad-2a99ad96bf03.md)
* [kcab461b-f44e-4d97-a041-ef7e64800587 (Bundle)](Bundle-kcab461b-f44e-4d97-a041-ef7e64800587.md)
* [ld31e08a-b91f-49c3-841a-ce80e6380517 (Bundle)](Bundle-ld31e08a-b91f-49c3-841a-ce80e6380517.md)
* [m908i967-9ie3-9023-b9ec-98108695f01d (Bundle)](Bundle-m908i967-9ie3-9023-b9ec-98108695f01d.md)
* [n73ccf30-80b9-4bd2-bf50-1ac1914498f0 (Bundle)](Bundle-n73ccf30-80b9-4bd2-bf50-1ac1914498f0.md)
* [a790f964-88d3-4652-bbc8-81d2f3d035f8 (Encounter)](Encounter-a790f964-88d3-4652-bbc8-81d2f3d035f8.md)
* [b9846c24-0335-11ed-b939-0242ac120002 (Encounter)](Encounter-b9846c24-0335-11ed-b939-0242ac120002.md)
* [c9782061-ce63-41b5-8be6-655812d23332 (Encounter)](Encounter-c9782061-ce63-41b5-8be6-655812d23332.md)
* [d56e9c54-23d2-43a4-816e-951d2a6e3281 (Encounter)](Encounter-d56e9c54-23d2-43a4-816e-951d2a6e3281.md)
* [e07c4bd4-cfad-4c4d-9c4b-e4ba3424a65b (Encounter)](Encounter-e07c4bd4-cfad-4c4d-9c4b-e4ba3424a65b.md)
* [f405ba2d-467a-4e92-9acc-9dc2a629760f (Encounter)](Encounter-f405ba2d-467a-4e92-9acc-9dc2a629760f.md)
* [gcab7218-9584-11ec-b909-0242ac120002 (Encounter)](Encounter-gcab7218-9584-11ec-b909-0242ac120002.md)
* [h2cb16ce-af8c-46f3-be9e-89406ef3e7b5 (Encounter)](Encounter-h2cb16ce-af8c-46f3-be9e-89406ef3e7b5.md)
* [kbbad98c-3310-404a-af0c-7e3739d7b49f (Encounter)](Encounter-kbbad98c-3310-404a-af0c-7e3739d7b49f.md)
* [l001c640-6b5d-414c-b6bd-e00ec6d4ceee (Encounter)](Encounter-l001c640-6b5d-414c-b6bd-e00ec6d4ceee.md)
* [m790f964-98d3-4852-bac8-83d2f3d035f8 (Encounter)](Encounter-m790f964-98d3-4852-bac8-83d2f3d035f8.md)
* [ne70f2b8-a924-11ed-afa1-0242ac120002 (Encounter)](Encounter-ne70f2b8-a924-11ed-afa1-0242ac120002.md)
* [1ca19ddf-31bc-4597-8739-968c38dd88f8 (MessageHeader)](MessageHeader-1ca19ddf-31bc-4597-8739-968c38dd88f8.md)
* [a1b27813-8aa8-4fa1-846b-aeabf5afb7d4 (MessageHeader)](MessageHeader-a1b27813-8aa8-4fa1-846b-aeabf5afb7d4.md)
* [b9b4818e-02de-4cc4-b418-d20cbc7b5404 (MessageHeader)](MessageHeader-b9b4818e-02de-4cc4-b418-d20cbc7b5404.md)
* [cc47c1e2-78e6-4291-b071-f423a4f7fbfe (MessageHeader)](MessageHeader-cc47c1e2-78e6-4291-b071-f423a4f7fbfe.md)
* [d8749b54-1aeb-4089-8941-8d876bdffc51 (MessageHeader)](MessageHeader-d8749b54-1aeb-4089-8941-8d876bdffc51.md)
* [e563a2b2-bf92-4b13-bbd2-0a021a95bded (MessageHeader)](MessageHeader-e563a2b2-bf92-4b13-bbd2-0a021a95bded.md)
* [f47254da-f170-46f0-b624-4778a9c92b1f (MessageHeader)](MessageHeader-f47254da-f170-46f0-b624-4778a9c92b1f.md)
* [g1affa53-c157-4080-abb0-8e681524f969 (MessageHeader)](MessageHeader-g1affa53-c157-4080-abb0-8e681524f969.md)
* [hefc6d95-6161-4493-99c9-f359488dedb8 (MessageHeader)](MessageHeader-hefc6d95-6161-4493-99c9-f359488dedb8.md)
* [i50fc5fe-2d11-4ef3-acac-2e2e5c6c0029 (MessageHeader)](MessageHeader-i50fc5fe-2d11-4ef3-acac-2e2e5c6c0029.md)
* [j3675c4a-33db-40f1-b578-ff16e3e9134c (MessageHeader)](MessageHeader-j3675c4a-33db-40f1-b578-ff16e3e9134c.md)
* [m9bea09c-e662-4d59-b84f-9af570b57f42 (MessageHeader)](MessageHeader-m9bea09c-e662-4d59-b84f-9af570b57f42.md)
* [nabb68aa-c97b-4905-a60c-71ff3209fd51 (MessageHeader)](MessageHeader-nabb68aa-c97b-4905-a60c-71ff3209fd51.md)
* [o9b4818e-12de-5cc4-c418-d30cbc7b5404 (MessageHeader)](MessageHeader-o9b4818e-12de-5cc4-c418-d30cbc7b5404.md)
