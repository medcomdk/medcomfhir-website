# Home - Danish profile of the IHE XDS Metadata Standard v2.0.0-trial-use-1

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://medcomfhir.dk/ig/xdsmetadata/ImplementationGuide/medcom.fhir.dk.xdsmetadata | *Version*:2.0.0-trial-use-1 |
| Draft as of 2026-05-29 | *Computable Name*:DanishprofileoftheIHEXDSMetadataStandard |

# XDS Metadata for Document Sharing - Danish Profile

This Implementation Guide (IG) is a FHIR representation of the [ValueSets in provided here for the IHE-XDS metadata](https://svn.medcom.dk/svn/releases/Standarder/IHE/OID/). The ValueSets are used to define the allowed codes for a coded element in the metadata standard. A FHIR representation of the [IHE-XDS metadata standard](https://svn.medcom.dk/svn/releases/Standarder/IHE/DK_profil_metadata/) has also been developed using the FHIR resource DocumentReference. The [profile MedComDocumentReference](https://build.fhir.org/ig/medcomdk/dk-medcom-document/StructureDefinition-medcom-documentreference.html) includes bindings to the ValueSets in this IG.

> Note: The [IHE-XDS metadata standard](https://svn.medcom.dk/svn/releases/Standarder/IHE/DK_profil_metadata/) and [IHE-XDS metadata ValueSets](https://svn.medcom.dk/svn/releases/Standarder/IHE/OID/) are currently the valid representation of the allowed metadata and codes, respectively.

## What is the XDS-metadata profile?

The Danish Profile is based upon the international [IHE Profile](https://profiles.ihe.net/ITI/papers/metadata/index.html)

Standarden definerer en række metadataelementer, der er knyttet til sundhedsdokumenter, og som tillader en ensartet og struktureret beskrivelse af dokumenterne. Formålet er at muliggøre en pålidelig og sikker udveksling af dokumenter.

Standarden bliver anvendt i bl.a. Et Samlet Patientoverblik, Graviditetsmappen og PRO-løsningerne til opmærkning af dokumenter i dokumentdelingsservicens SDS Patientindeks. Derfra anvendes standarden til afgrænsning af dokumentudsøgning.

Ejerskabsoverdragelsen vil centralisere ansvaret for løbende revision af XSD-metadata, hvilket resulterer i en hurtigere og mere effektiv specifikation af søgeparametre. Dette vil gavne både leverandører og slutbrugere ved at levere præcise og mere relevante søgeresultater.

Du finder standarddokumentationen på MedComs SVN.

# Terminology for XDS Metadata

## Content

This IG includes ValueSets used in the MedComDocumentReference profile. Further, it includes relevant CodeSystems defined by MedCom.

### ValueSets

Codes represented in the ValueSets comes from more CodeSystems, intended for use in a particular context. For each coded element in the DocumentReference profile, a ValueSet is included. The included ValueSet can either be generic across metadata for all standards, e.g. [HealthCareFacilityTypeCode](https://build.fhir.org/ig/medcomdk/dk-medcom-xds-metadata/ValueSet-MedCom-xds-HealthcareFacilityTypeCode-VS.html), or specific for the individual standard, e.g. [formatcode](https://build.fhir.org/ig/medcomdk/dk-medcom-xds-metadata/ValueSet-MedCom-ihe-plr-formatcode-VS.html). Therefore, several ValueSets for representing e.g. formatCode can be found, one for each type of MedCom document standard.

### CodeSystems

CodeSystems defines which codes exists and how they should be understood to avoid ambiguities. As mentioned, this IG only includes relevant CodeSystems defined by MedCom, whereas CodeSystems defined by other organizations can be found elsewhere.

The codes in the ValueSet originate from different CodeSystems that are owned by various organizations. In the table below, these CodeSystems are presented with an OID, name, description from the [OID-repository](http://www.oid-info.com/), owner of the CodeSystem, and a reference to the CodeSystem if it is different from the OID listed below.

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| 2.16.840.1.113883.6.96 | SCT | Systematized Nomenclature Of MEDicine (SNOMED) Clinical Terms (CT) | IHTSDO | http://snomed.info/sct|http://snomed.info/sct/554471000005108/version/20260331 |
| 2.16.840.1.113883.6.1 | LOINC | Logical Observation Identifier Names and Codes (LOINC) | Regenstrief Institute | http://loinc.org |
| 2.16.840.1.113883.5.79 | mediaType | mediaType | HL7 | urn:ietf:bcp:13 |
| 2.16.840.1.113883.6.121 | ieft3066 | Tags for the Identification of Languages | HL7 | urn:ietf:bcp:47 |
| 2.16.840.1.113883.5.25 | Confidentiality | Confidentiality | HL7 | http://terminology.hl7.org/CodeSystem/v3-Confidentiality |
| 1.2.208.176.2.4 | SKS | Danish collection of code systems in national health reporting (in Danish, Sundhedsvæsenets Klassifikations System (SKS)) | Danish Health Data Authority |  |
| 1.2.208.176.2.1 | NPU | Nomenclature for Properties and Units (NPU) terminology in Danish | Danish Health Data Authority | http://npu-terminology.org |
| 1.2.208.176.7.3.1 | schema-list | Questionnaires used in the Danish Patient Reported Outcome (PRO) | Danish Health Data Authority |  |
| 1.2.208.176.8.1 | ihe | Integrating the Healthcare Enterprise (IHE) cross[X]-enterprise Document Sharing (XDS) domain | Danish Health Data Authority | http://medcomfhir.dk/ig/xdsmetadata/CodeSystem/MedCom-xds-homeCommunityId-CS |
| 1.2.208.184.100.9 | classcode | Danish Integrating the Healthcare Enterprise (IHE) metadata class codes | MedCom | http://medcomfhir.dk/ig/xdsmetadata/CodeSystem/MedCom-xds-classcode-CS |
| 1.2.208.184.100.1 | message-codes | Message codes administered by MedCom | MedCom | http://medcomfhir.dk/ig/xdsmetadata/CodeSystem/MedCom-ihe-typecode-CS |
| 1.2.208.184.100.10 | formatcode | Danish Integrating the Healthcare Enterprise (IHE) metadata format codes | MedCom | http://medcomfhir.dk/ig/xdsmetadata/CodeSystem/MedCom-ihe-formatcode-CS |

## Usage

​Currently it is possible to [download](downloads.md) the ValueSets and CodeSystems in different formats. The vendor of the system is responsible for using updated terminologies.

The date of the recent update can be seen in the bottom of this page, but to see if a specific CodeSystem, ValueSet or ConceptMap is updated, you’ll have to look at the specific terminology and see if the version has been changed. In the ‘History’-tab the history of the IG can be seen.

## Contact

[MedCom](https://medcom.dk/) is responsible for this site. If you have any questions, please contact [fhir@medcom.dk](mailto:fhir@medcom.dk) or write to MedCom’s stream in [Zulip](https://chat.fhir.org/#narrow/stream/315677-denmark.2Fmedcom.2FFHIRimplementationErfaGroup).

