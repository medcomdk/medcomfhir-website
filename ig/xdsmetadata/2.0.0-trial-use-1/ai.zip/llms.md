# medcom.fhir.dk.xdsmetadata#2.0.0-trial-use-1: Danish profile of the IHE XDS Metadata Standard

## Pages

* [Home](index.md)
* [XDS Metadata for Document Sharing Danish Profile v 1 0 0](XDS_Metadata_for_Document_Sharing_Danish_profile_v.1.0.0.md)
* [XDS Metadata for Document Sharing Danish Profile v 2 0 0 Ebxml](XDS_Metadata_for_Document_Sharing_Danish_profile_v.2.0.0_ebxml.md)
* [XDS Metadata for Document Sharing Danish Profile v 1 0 1](XDS_Metadata_for_Document_Sharing_Danish_profile_v.1.0.1.md)
* [Dependencies](dependencies.md)
* [Downloads](downloads.md)
* [XDS Metadata for Document Sharing Danish Profile v 2 0 0](XDS_Metadata_for_Document_Sharing_Danish_profile_v.2.0.0.md)
* [Roadmap](roadmap.md)
* [DK XDS Metadata Value Sets](DK-XDS_Metadata-Value_sets.md)
* [XDS Metadata for Document Sharing Danish Profile v 2 0 0 Cda](XDS_Metadata_for_Document_Sharing_Danish_profile_v.2.0.0_cda.md)
* [Artifacts Summary](artifacts.md)
* [XDS Metadata for Document Sharing Danish Profile v 2 0 0 Fhir](XDS_Metadata_for_Document_Sharing_Danish_profile_v.2.0.0_fhir.md)

## Resources

### CodeSystems

* [DK MedCom analysis codes](CodeSystem-MedCom-xds-analysis-codes-CS.md)
* [DK XDS ClassCode](CodeSystem-MedCom-xds-classcode-CS.md)
* [DK XDS FormatCode](CodeSystem-MedCom-xds-formatcode-CS.md)
* [DK XDS Affinity Domain](CodeSystem-MedCom-xds-homeCommunityId-CS.md)
* [DK MedCom Message Codes](CodeSystem-MedCom-xds-typecode-CS.md)

### ValueSets

* [DK XDS HealthcareFacilityTypeCode](ValueSet-MedCom-xds-HealthcareFacilityTypeCode-VS.md)
* [DK XDS PracticeSettingCode](ValueSet-MedCom-xds-PracticeSettingCode-VS.md)
* [DK XDS ClassCode](ValueSet-MedCom-xds-classcode-VS.md)
* [DK XDS ConfidentialityCode](ValueSet-MedCom-xds-confidentialitycode-VS.md)
* [DK XDS EventCodeLists](ValueSet-MedCom-xds-eventcodelist-VS.md)
* [DK XDS FormatCode](ValueSet-MedCom-xds-formatcode-VS.md)
* [DK XDS HomeCommunityId](ValueSet-MedCom-xds-homeCommunityId-VS.md)
* [DK XDS LanguageCode](ValueSet-MedCom-xds-languagecode-VS.md)
* [DK XDS MimeType for FHIR documents](ValueSet-MedCom-xds-mimetype-fhir-VS.md)
* [DK XDS MimeType for non-FHIR XML documents](ValueSet-MedCom-xds-mimetype-xml-VS.md)
* [DK XDS TypeCode ValueSet](ValueSet-MedCom-xds-typecode-VS.md)

### ConceptMaps

* [OID to CodeSystem Reference ConceptMap](ConceptMap-MedComConceptMapOIDToCodeSystemReference.md)

### ImplementationGuides

* [Danish profile of the IHE XDS Metadata Standard](index.md)
