# medcom.fhir.dk.core#1.0.0-test: DK MedCom Core

## Pages

* [Home](index.md)
* [Downloads](downloads.md)
* [Producer of FHIR resources - JSON Representation](ActorDefinition-ProducerActor.json.md)
* [Producer of FHIR resources - Testing](ActorDefinition-ProducerActor-testing.md)
* [Validation](validation.md)
* [Narrative Legacy](narrative-legacy.md)
* [Itb Getting Started](itb-getting-started.md)
* [Terminology](terminology.md)
* [Dependencies](dependencies.md)
* [](ActorDefinition-ProducerActor.change.history.md)
* [Artifacts Summary](artifacts.md)
* [Test and Certification](test-and-certification.md)
* [Producer of FHIR resources - TTL Representation](ActorDefinition-ProducerActor.ttl.md)
* [Versioning Change Management](versioning-change-management.md)
* [Producer of FHIR resources - XML Representation](ActorDefinition-ProducerActor.xml.md)
* [Profiles](profiles.md)
* [General Governance](general-governance.md)
* [New to Fhir](new-to-fhir.md)
* [Extensions](extensions.md)
* [Producer of FHIR resources](ActorDefinition-ProducerActor.md)
* [Faq](faq.md)

## Resources

### Complex-type Profiles

* [LPR3 Identifier](StructureDefinition-lpr3-Identifier.md)
* [AssignedIdentifier](StructureDefinition-medcom-assigned-identifier.md)

### Resource Profiles

* [MedComCoreCareTeam](StructureDefinition-medcom-core-careteam.md)
* [MedComCoreDiagnosticReport](StructureDefinition-medcom-core-diagnosticreport.md)
* [MedComCoreEncounter](StructureDefinition-medcom-core-encounter.md)
* [MedComMedia](StructureDefinition-medcom-core-media.md)
* [MedComCoreObservation](StructureDefinition-medcom-core-observation.md)
* [MedComCoreOrganization](StructureDefinition-medcom-core-organization.md)
* [MedComCorePatient](StructureDefinition-medcom-core-patient.md)
* [MedComCorePractitioner](StructureDefinition-medcom-core-practitioner.md)
* [MedComCorePractitionerRole](StructureDefinition-medcom-core-practitionerrole.md)

### Extensions

* [ContactExtension](StructureDefinition-medcom-core-contact-extension.md)
* [DateTimeExtension](StructureDefinition-medcom-core-datetime-extension.md)
* [IdentifierExtension](StructureDefinition-medcom-core-identifier-extension.md)
* [PractitionerExtension](StructureDefinition-medcom-core-practitioner-extension.md)
* [SenderExtension](StructureDefinition-medcom-core-sender-extension.md)
* [MedCom Observation ValueAttachment Extension](StructureDefinition-medcom-observation-value-attachment-extension.md)

### ImplementationGuides

* [DK MedCom Core](index.md)

### Examples

* [ProducerActor (Basic)](Basic-ProducerActor.md)
* [Team 2 (CareTeam)](CareTeam-fb1d34fe-6672-11ed-9022-0242ac120002.md)
* [6220b42d-c4fd-4c77-bae7-78e7d890dc8d (Encounter)](Encounter-6220b42d-c4fd-4c77-bae7-78e7d890dc8d.md)
* [cb277ee2-5d96-4762-829d-d36449b2b17f (Media)](Media-cb277ee2-5d96-4762-829d-d36449b2b17f.md)
* [Aros Burn Center (Organization)](Organization-12ee0dde-a672-462f-820d-5efe832d73c9.md)
* [bca68510-fe3b-4161-aba0-908a693eb54f (Organization)](Organization-bca68510-fe3b-4161-aba0-908a693eb54f.md)
* [382fb8a3-6725-41e2-a615-2b1cfcfe9931 (Patient)](Patient-382fb8a3-6725-41e2-a615-2b1cfcfe9931.md)
* [5b72c625-0570-4111-b272-f0351344f8b6 (Patient)](Patient-5b72c625-0570-4111-b272-f0351344f8b6.md)
* [733cef33-3626-422b-955d-d506aaa65fe1 (Patient)](Patient-733cef33-3626-422b-955d-d506aaa65fe1.md)
* [ded1fc9a-aa93-4162-aaec-7145a8ac951f (Patient)](Patient-ded1fc9a-aa93-4162-aaec-7145a8ac951f.md)
* [e9eacb62-666b-11ed-9022-0242ac120002 (Practitioner)](Practitioner-e9eacb62-666b-11ed-9022-0242ac120002.md)
* [6057686e-666c-11ed-9022-0242ac120002 (PractitionerRole)](PractitionerRole-6057686e-666c-11ed-9022-0242ac120002.md)
* [6ff69f1c-690d-11ed-9022-0242ac120002 (PractitionerRole)](PractitionerRole-6ff69f1c-690d-11ed-9022-0242ac120002.md)
