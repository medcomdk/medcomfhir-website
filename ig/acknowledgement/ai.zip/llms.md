# medcom.fhir.dk.acknowledgement#2.0.3: DK MedCom acknowledgement

## Pages

* [Home](index.md)
* [Profiles](profiles.md)
* [Extensions](extensions.md)
* [Artifacts Summary](artifacts.md)
* [Forsendelseskuvert for FHIR Meddelelser](Forsendelseskuvert_for_FHIR-meddelelser.md)
* [Enclosing Envelope for FHIR Messages](Enclosing_envelope_for_FHIR-messages.md)
* [Examples](examples.md)
* [Downloads](downloads.md)

## Resources

### Resource Profiles

* [MedComAcknowledgementOperationOutcome](StructureDefinition-medcom-acknowledgement-operationoutcome.md)
* [MedComAcknowledgementMessage](StructureDefinition-medcom-messaging-acknowledgement.md)
* [MedComAcknowledgementMessageHeader](StructureDefinition-medcom-messaging-acknowledgementHeader.md)

### ImplementationGuides

* [DK MedCom acknowledgement](index.md)

### Examples

* [a8c041b8-c65a-4fde-a90f-962076918834 (Bundle)](Bundle-a8c041b8-c65a-4fde-a90f-962076918834.md)
* [bc9535ef-ed94-4060-a928-7baddec7ee71 (Bundle)](Bundle-bc9535ef-ed94-4060-a928-7baddec7ee71.md)
* [c9c2b2f6-0807-11ed-861d-0242ac120002 (Bundle)](Bundle-c9c2b2f6-0807-11ed-861d-0242ac120002.md)
* [eb26be85-fdb7-454d-a980-95cba6d1745b (Bundle)](Bundle-eb26be85-fdb7-454d-a980-95cba6d1745b.md)
* [3881874e-2042-4a00-aee8-23512799f512 (MessageHeader)](MessageHeader-3881874e-2042-4a00-aee8-23512799f512.md)
* [42cb9200-f421-4d08-8391-7d51a2503cb4 (MessageHeader)](MessageHeader-42cb9200-f421-4d08-8391-7d51a2503cb4.md)
* [aba2d9bf-2c6c-47e8-bce4-7928bcd51019 (MessageHeader)](MessageHeader-aba2d9bf-2c6c-47e8-bce4-7928bcd51019.md)
* [b879c81e-0607-4ccb-b358-24a72208e30d (MessageHeader)](MessageHeader-b879c81e-0607-4ccb-b358-24a72208e30d.md)
* [c9a0b728-0807-11ed-861d-0242ac120002 (MessageHeader)](MessageHeader-c9a0b728-0807-11ed-861d-0242ac120002.md)
* [a87bc9d4-f876-4b6f-8585-40b26dc1e369 (OperationOutcome)](OperationOutcome-a87bc9d4-f876-4b6f-8585-40b26dc1e369.md)
* [becb2a8e-3a68-4083-910e-811296affd43 (OperationOutcome)](OperationOutcome-becb2a8e-3a68-4083-910e-811296affd43.md)
* [c0055484-2a56-4da2-81b8-a9d5087d865c (OperationOutcome)](OperationOutcome-c0055484-2a56-4da2-81b8-a9d5087d865c.md)
* [Receiver Organization (Organization)](Organization-74cdf292-abf3-4f5f-80ea-60a48013ff6d.md)
* [Sender Organization (Organization)](Organization-d7056980-a8b2-42aa-8a0e-c1fc85d1f40d.md)
* [382fb8a3-6725-41e2-a615-2b1cfcfe9931 (Patient)](Patient-382fb8a3-6725-41e2-a615-2b1cfcfe9931.md)
* [4c284936-5454-4116-95fc-3c8eeeed2400 (Provenance)](Provenance-4c284936-5454-4116-95fc-3c8eeeed2400.md)
* [69dab277-dd4b-4055-9fda-a10a65cb4412 (Provenance)](Provenance-69dab277-dd4b-4055-9fda-a10a65cb4412.md)
* [9b56aa88-9745-12ec-b919-0242ac122002 (Provenance)](Provenance-9b56aa88-9745-12ec-b919-0242ac122002.md)
* [9c56ba88-9645-11ec-b909-0242ac120002 (Provenance)](Provenance-9c56ba88-9645-11ec-b909-0242ac120002.md)
