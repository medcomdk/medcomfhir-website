# Dependencies - DK MedCom Carecommunication v5.0.4

* [**Table of Contents**](toc.md)
* **Dependencies**

## Dependencies


















*There are no Global profiles defined*

