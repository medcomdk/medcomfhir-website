# New CareCommunication message. - DK MedCom Carecommunication v5.0.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **New CareCommunication message.**

## Example Bundle: New CareCommunication message.



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "0d5b3c18-fab6-4d93-9d88-c9c8abf1f18c",
  "meta" : {
    "profile" : [
      "http://medcomfhir.dk/ig/carecommunication/StructureDefinition/medcom-careCommunication-message"
    ]
  },
  "type" : "message",
  "timestamp" : "2024-06-01T13:55:00+02:00",
  "entry" : [
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/MessageHeader/025bdfdd-397b-43e2-9e8c-272664a6e471",
      "resource" : {
        "resourceType" : "MessageHeader",
        "id" : "025bdfdd-397b-43e2-9e8c-272664a6e471",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/carecommunication/StructureDefinition/medcom-careCommunication-messageHeader"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_025bdfdd-397b-43e2-9e8c-272664a6e471\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader 025bdfdd-397b-43e2-9e8c-272664a6e471</b></p><a name=\"025bdfdd-397b-43e2-9e8c-272664a6e471\"> </a><a name=\"hc025bdfdd-397b-43e2-9e8c-272664a6e471\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-careCommunication-messageHeader.html\">MedComCareCommunicationMessageHeader</a></p></div><p><b>event</b>: <a href=\"http://medcomfhir.dk/ig/terminology/2.0.1/CodeSystem-medcom-messaging-eventCodes.html#medcom-messaging-eventCodes-care-communication-message\">MedComMessagingEventCodes: care-communication-message</a> (Care Communication Message)</p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Endpoint</b></td><td><b>Receiver</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><a href=\"https://sor2.sum.dsdn.dk/#id=953741000016009\">https://sor2.sum.dsdn.dk/#id=953741000016009</a></td><td><a href=\"Organization-b2f762be-6994-44da-a214-72c765655b3e.html\">Organization Plejecenter Herlev</a></td></tr></table><p><b>sender</b>: <a href=\"Organization-0ece868c-6a72-4aa3-8a96-2d985ab630c7.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://sor2.sum.dsdn.dk/#id=265161000016000\">https://sor2.sum.dsdn.dk/#id=265161000016000</a></td></tr></table><p><b>focus</b>: <a href=\"Communication-d8434eb5-8286-48f8-a590-4a27175ed82f.html\">Communication: identifier = urn:uuid:cefe0dee-13b5-4bec-a843-09b4d58e4fe6; status = unknown; category = Undersøgelsessvar</a></p><p><b>definition</b>: <a href=\"http://medcomfhir.dk/ig/messagedefinitions/1.0.0/MessageDefinition-MedComCareCommunicationMessageDefinitionV5.0.html\">http://medcomfhir.dk/ig/messagedefinitions/MessageDefinition/MedComCareCommunicationMessageDefinition|5.0</a></p></div>"
        },
        "eventCoding" : {
          "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-eventCodes",
          "code" : "care-communication-message"
        },
        "destination" : [
          {
            "extension" : [
              {
                "url" : "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-destinationUseExtension",
                "valueCoding" : {
                  "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-destinationUse",
                  "code" : "primary"
                }
              }
            ],
            "endpoint" : "https://sor2.sum.dsdn.dk/#id=953741000016009",
            "receiver" : {
              "reference" : "Organization/b2f762be-6994-44da-a214-72c765655b3e"
            }
          }
        ],
        "sender" : {
          "reference" : "Organization/0ece868c-6a72-4aa3-8a96-2d985ab630c7"
        },
        "source" : {
          "endpoint" : "https://sor2.sum.dsdn.dk/#id=265161000016000"
        },
        "focus" : [
          {
            "reference" : "Communication/d8434eb5-8286-48f8-a590-4a27175ed82f"
          }
        ],
        "definition" : "http://medcomfhir.dk/ig/messagedefinitions/MessageDefinition/MedComCareCommunicationMessageDefinition|5.0"
      }
    },
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/Patient/50c51ef0-00b0-429a-b212-35ee0773fd5a",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "50c51ef0-00b0-429a-b212-35ee0773fd5a",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_50c51ef0-00b0-429a-b212-35ee0773fd5a\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient 50c51ef0-00b0-429a-b212-35ee0773fd5a</b></p><a name=\"50c51ef0-00b0-429a-b212-35ee0773fd5a\"> </a><a name=\"hc50c51ef0-00b0-429a-b212-35ee0773fd5a\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/3.0.1/StructureDefinition-medcom-core-patient.html\">MedComCorePatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Birgit Berggren (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.6.1.1#0703921VJ4 (use: temp, ))</p><hr/></div>"
        },
        "identifier" : [
          {
            "use" : "temp",
            "system" : "urn:oid:1.2.208.176.1.6.1.1",
            "value" : "0703921VJ4"
          }
        ],
        "name" : [
          {
            "use" : "official",
            "family" : "Berggren",
            "given" : ["Birgit"]
          }
        ]
      }
    },
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/Communication/d8434eb5-8286-48f8-a590-4a27175ed82f",
      "resource" : {
        "resourceType" : "Communication",
        "id" : "d8434eb5-8286-48f8-a590-4a27175ed82f",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/carecommunication/StructureDefinition/medcom-careCommunication-communication"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Communication_d8434eb5-8286-48f8-a590-4a27175ed82f\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Communication d8434eb5-8286-48f8-a590-4a27175ed82f</b></p><a name=\"d8434eb5-8286-48f8-a590-4a27175ed82f\"> </a><a name=\"hcd8434eb5-8286-48f8-a590-4a27175ed82f\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-careCommunication-communication.html\">MedComCareCommunication</a></p></div><p><b>identifier</b>: urn:uuid:cefe0dee-13b5-4bec-a843-09b4d58e4fe6</p><p><b>status</b>: Unknown</p><p><b>category</b>: <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-careCommunication-categoryCodes examination-results}\">Undersøgelsessvar</span></p><p><b>subject</b>: <a href=\"Patient-50c51ef0-00b0-429a-b212-35ee0773fd5a.html\">Birgit Berggren (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.6.1.1#0703921VJ4 (use: temp, ))</a></p><blockquote><p><b>payload</b></p><p><b>DateTimeExtension</b>: 2024-06-01 13:55:00+0200</p><p><b>IdentifierExtension</b>: urn:uuid:24d01288-ad36-4af2-96a8-fd1432dadee1</p><p><b>PractitionerExtension</b>: <a href=\"PractitionerRole-2e8c8e54-388c-4547-954c-1917652986da.html\">PractitionerRole Sygeplejerske</a></p><p><b>ContactExtension</b>: ph: 38683868</p><p><b>content</b>: Til rette vedkommende. Vi ønsker information om de seneste undersøgelser udført på Bruno. På forhånd tak. Hilsen Michael, sygeplejerske.</p></blockquote></div>"
        },
        "identifier" : [
          {
            "value" : "urn:uuid:cefe0dee-13b5-4bec-a843-09b4d58e4fe6"
          }
        ],
        "status" : "unknown",
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-careCommunication-categoryCodes",
                "code" : "examination-results"
              }
            ]
          }
        ],
        "subject" : {
          "reference" : "Patient/50c51ef0-00b0-429a-b212-35ee0773fd5a"
        },
        "payload" : [
          {
            "extension" : [
              {
                "url" : "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-datetime-extension",
                "valueDateTime" : "2024-06-01T13:55:00+02:00"
              },
              {
                "url" : "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-identifier-extension",
                "valueIdentifier" : {
                  "value" : "urn:uuid:24d01288-ad36-4af2-96a8-fd1432dadee1",
                  "assigner" : {
                    "reference" : "Organization/0ece868c-6a72-4aa3-8a96-2d985ab630c7"
                  }
                }
              },
              {
                "url" : "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-practitioner-extension",
                "valueReference" : {
                  "reference" : "PractitionerRole/2e8c8e54-388c-4547-954c-1917652986da"
                }
              },
              {
                "url" : "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-contact-extension",
                "valueContactPoint" : {
                  "system" : "phone",
                  "value" : "38683868"
                }
              }
            ],
            "contentString" : "Til rette vedkommende. Vi ønsker information om de seneste undersøgelser udført på Bruno. På forhånd tak. Hilsen Michael, sygeplejerske."
          }
        ]
      }
    },
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/PractitionerRole/2e8c8e54-388c-4547-954c-1917652986da",
      "resource" : {
        "resourceType" : "PractitionerRole",
        "id" : "2e8c8e54-388c-4547-954c-1917652986da",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-practitionerrole"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_2e8c8e54-388c-4547-954c-1917652986da\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole 2e8c8e54-388c-4547-954c-1917652986da</b></p><a name=\"2e8c8e54-388c-4547-954c-1917652986da\"> </a><a name=\"hc2e8c8e54-388c-4547-954c-1917652986da\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/3.0.1/StructureDefinition-medcom-core-practitionerrole.html\">MedComCorePractitionerRole</a></p></div><p><b>practitioner</b>: <a href=\"Practitioner-97511212-12e6-4182-a42b-cf232c0c117c.html\">Practitioner Michael Burns </a></p><p><b>code</b>: <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-PractitionerRolesSKSadministrativ sygeplejerske}\">Sygeplejerske</span></p></div>"
        },
        "practitioner" : {
          "reference" : "Practitioner/97511212-12e6-4182-a42b-cf232c0c117c"
        },
        "code" : [
          {
            "coding" : [
              {
                "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-PractitionerRolesSKSadministrativ",
                "code" : "sygeplejerske"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/Practitioner/97511212-12e6-4182-a42b-cf232c0c117c",
      "resource" : {
        "resourceType" : "Practitioner",
        "id" : "97511212-12e6-4182-a42b-cf232c0c117c",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-practitioner"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_97511212-12e6-4182-a42b-cf232c0c117c\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner 97511212-12e6-4182-a42b-cf232c0c117c</b></p><a name=\"97511212-12e6-4182-a42b-cf232c0c117c\"> </a><a name=\"hc97511212-12e6-4182-a42b-cf232c0c117c\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/3.0.1/StructureDefinition-medcom-core-practitioner.html\">MedComCorePractitioner</a></p></div><p><b>name</b>: Michael Burns </p></div>"
        },
        "name" : [
          {
            "family" : "Burns",
            "given" : ["Michael"]
          }
        ]
      }
    },
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/Organization/b2f762be-6994-44da-a214-72c765655b3e",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "b2f762be-6994-44da-a214-72c765655b3e",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_b2f762be-6994-44da-a214-72c765655b3e\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization b2f762be-6994-44da-a214-72c765655b3e</b></p><a name=\"b2f762be-6994-44da-a214-72c765655b3e\"> </a><a name=\"hcb2f762be-6994-44da-a214-72c765655b3e\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/4.0.2/StructureDefinition-medcom-messaging-organization.html\">MedComMessagingOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790001348120, <code>urn:oid:1.2.208.176.1.1</code>/953741000016009</p><p><b>name</b>: Plejecenter Herlev</p></div>"
        },
        "identifier" : [
          {
            "system" : "https://www.gs1.org/gln",
            "value" : "5790001348120"
          },
          {
            "system" : "urn:oid:1.2.208.176.1.1",
            "value" : "953741000016009"
          }
        ],
        "name" : "Plejecenter Herlev"
      }
    },
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/Organization/0ece868c-6a72-4aa3-8a96-2d985ab630c7",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "0ece868c-6a72-4aa3-8a96-2d985ab630c7",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_0ece868c-6a72-4aa3-8a96-2d985ab630c7\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization 0ece868c-6a72-4aa3-8a96-2d985ab630c7</b></p><a name=\"0ece868c-6a72-4aa3-8a96-2d985ab630c7\"> </a><a name=\"hc0ece868c-6a72-4aa3-8a96-2d985ab630c7\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/4.0.2/StructureDefinition-medcom-messaging-organization.html\">MedComMessagingOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790000209354, <code>urn:oid:1.2.208.176.1.1</code>/265161000016000</p><p><b>name</b>: Hjerteafdelingen på Herlev og Gentofte hospital</p></div>"
        },
        "identifier" : [
          {
            "system" : "https://www.gs1.org/gln",
            "value" : "5790000209354"
          },
          {
            "system" : "urn:oid:1.2.208.176.1.1",
            "value" : "265161000016000"
          }
        ],
        "name" : "Hjerteafdelingen på Herlev og Gentofte hospital"
      }
    },
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/Provenance/d0cbe580-b47c-4858-ab5e-6c4ba3d2de2a",
      "resource" : {
        "resourceType" : "Provenance",
        "id" : "d0cbe580-b47c-4858-ab5e-6c4ba3d2de2a",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/carecommunication/StructureDefinition/medcom-careCommunication-provenance"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_d0cbe580-b47c-4858-ab5e-6c4ba3d2de2a\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance d0cbe580-b47c-4858-ab5e-6c4ba3d2de2a</b></p><a name=\"d0cbe580-b47c-4858-ab5e-6c4ba3d2de2a\"> </a><a name=\"hcd0cbe580-b47c-4858-ab5e-6c4ba3d2de2a\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-careCommunication-provenance.html\">MedComCareCommunicationProvenance</a></p></div><p>Provenance for <a href=\"MessageHeader-025bdfdd-397b-43e2-9e8c-272664a6e471.html\">MessageHeader: event[x] = Care Communication Message (MedComMessagingEventCodes#care-communication-message); definition = http://medcomfhir.dk/ig/messagedefinitions/MessageDefinition/MedComCareCommunicationMessageDefinition|5.0</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>2024-06-01 13:55:00+0200</td></tr><tr><td>Recorded</td><td>2024-06-01 13:55:00+0200</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes new-message}\">A new message has been sent</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>who</b></td></tr><tr><td><a href=\"Organization-0ece868c-6a72-4aa3-8a96-2d985ab630c7.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></td></tr></table></div>"
        },
        "target" : [
          {
            "reference" : "MessageHeader/025bdfdd-397b-43e2-9e8c-272664a6e471"
          }
        ],
        "occurredDateTime" : "2024-06-01T13:55:00+02:00",
        "recorded" : "2024-06-01T13:55:00+02:00",
        "activity" : {
          "coding" : [
            {
              "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes",
              "code" : "new-message"
            }
          ]
        },
        "agent" : [
          {
            "who" : {
              "reference" : "Organization/0ece868c-6a72-4aa3-8a96-2d985ab630c7"
            }
          }
        ],
        "entity" : [
          {
            "role" : "source",
            "what" : {
              "identifier" : {
                "value" : "urn:uuid:24d01288-ad36-4af2-96a8-fd1432dadee1"
              }
            }
          }
        ]
      }
    }
  ]
}

```
