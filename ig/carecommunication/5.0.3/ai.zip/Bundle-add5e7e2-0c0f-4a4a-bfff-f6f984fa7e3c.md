# 1st message - New CareCommunication message. - DK MedCom Carecommunication v5.0.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **1st message - New CareCommunication message.**

## Example Bundle: 1st message - New CareCommunication message.



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "add5e7e2-0c0f-4a4a-bfff-f6f984fa7e3c",
  "meta" : {
    "profile" : [
      "http://medcomfhir.dk/ig/carecommunication/StructureDefinition/medcom-careCommunication-message"
    ]
  },
  "type" : "message",
  "timestamp" : "2024-05-01T12:00:00+02:00",
  "entry" : [
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/MessageHeader/42cb9200-f421-4d08-8391-7d51a2503cb4",
      "resource" : {
        "resourceType" : "MessageHeader",
        "id" : "42cb9200-f421-4d08-8391-7d51a2503cb4",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/carecommunication/StructureDefinition/medcom-careCommunication-messageHeader"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_42cb9200-f421-4d08-8391-7d51a2503cb4\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader 42cb9200-f421-4d08-8391-7d51a2503cb4</b></p><a name=\"42cb9200-f421-4d08-8391-7d51a2503cb4\"> </a><a name=\"hc42cb9200-f421-4d08-8391-7d51a2503cb4\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-careCommunication-messageHeader.html\">MedComCareCommunicationMessageHeader</a></p></div><p><b>event</b>: <a href=\"http://medcomfhir.dk/ig/terminology/2.0.1/CodeSystem-medcom-messaging-eventCodes.html#medcom-messaging-eventCodes-care-communication-message\">MedComMessagingEventCodes: care-communication-message</a> (Care Communication Message)</p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Endpoint</b></td><td><b>Receiver</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><a href=\"https://sor2.sum.dsdn.dk/#id=953741000016009\">https://sor2.sum.dsdn.dk/#id=953741000016009</a></td><td><a href=\"Organization-487ac745-fd11-4879-9b59-c08c7d47260e.html\">Organization Plejecenter Herlev</a></td></tr></table><p><b>sender</b>: <a href=\"Organization-b581c63c-181f-46f6-990d-b9942c576724.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://sor2.sum.dsdn.dk/#id=265161000016000\">https://sor2.sum.dsdn.dk/#id=265161000016000</a></td></tr></table><p><b>focus</b>: <a href=\"Communication-94e65db8-2f0c-4a2c-a7c9-06a160d59a12.html\">Communication: identifier = urn:uuid:b2eb3d0e-5de5-4de9-b2a3-0ff321ad1c3a; status = unknown; category = Undersøgelsessvar; topic = </a></p><p><b>definition</b>: <a href=\"http://medcomfhir.dk/ig/messagedefinitions/1.0.0/MessageDefinition-MedComCareCommunicationMessageDefinitionV5.0.html\">http://medcomfhir.dk/ig/messagedefinitions/MessageDefinition/MedComCareCommunicationMessageDefinition|5.0</a></p></div>"
        },
        "eventCoding" : {
          "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-eventCodes",
          "code" : "care-communication-message"
        },
        "destination" : [
          {
            "extension" : [
              {
                "url" : "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-destinationUseExtension",
                "valueCoding" : {
                  "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-destinationUse",
                  "code" : "primary"
                }
              }
            ],
            "endpoint" : "https://sor2.sum.dsdn.dk/#id=953741000016009",
            "receiver" : {
              "reference" : "Organization/487ac745-fd11-4879-9b59-c08c7d47260e"
            }
          }
        ],
        "sender" : {
          "reference" : "Organization/b581c63c-181f-46f6-990d-b9942c576724"
        },
        "source" : {
          "endpoint" : "https://sor2.sum.dsdn.dk/#id=265161000016000"
        },
        "focus" : [
          {
            "reference" : "Communication/94e65db8-2f0c-4a2c-a7c9-06a160d59a12"
          }
        ],
        "definition" : "http://medcomfhir.dk/ig/messagedefinitions/MessageDefinition/MedComCareCommunicationMessageDefinition|5.0"
      }
    },
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/Patient/733cef33-3626-422b-955d-d506aaa65fe1",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "733cef33-3626-422b-955d-d506aaa65fe1",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_733cef33-3626-422b-955d-d506aaa65fe1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient 733cef33-3626-422b-955d-d506aaa65fe1</b></p><a name=\"733cef33-3626-422b-955d-d506aaa65fe1\"> </a><a name=\"hc733cef33-3626-422b-955d-d506aaa65fe1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/3.0.1/StructureDefinition-medcom-core-patient.html\">MedComCorePatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Bruno Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</p><hr/></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:1.2.208.176.1.2",
            "value" : "2509479989"
          }
        ],
        "name" : [
          {
            "use" : "official",
            "family" : "Elmer",
            "given" : ["Bruno"]
          }
        ]
      }
    },
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/Communication/94e65db8-2f0c-4a2c-a7c9-06a160d59a12",
      "resource" : {
        "resourceType" : "Communication",
        "id" : "94e65db8-2f0c-4a2c-a7c9-06a160d59a12",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/carecommunication/StructureDefinition/medcom-careCommunication-communication"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Communication_94e65db8-2f0c-4a2c-a7c9-06a160d59a12\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Communication 94e65db8-2f0c-4a2c-a7c9-06a160d59a12</b></p><a name=\"94e65db8-2f0c-4a2c-a7c9-06a160d59a12\"> </a><a name=\"hc94e65db8-2f0c-4a2c-a7c9-06a160d59a12\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-careCommunication-communication.html\">MedComCareCommunication</a></p></div><p><b>identifier</b>: urn:uuid:b2eb3d0e-5de5-4de9-b2a3-0ff321ad1c3a</p><p><b>status</b>: Unknown</p><p><b>category</b>: <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-careCommunication-categoryCodes examination-results}\">Undersøgelsessvar</span></p><p><b>subject</b>: <a href=\"Patient-733cef33-3626-422b-955d-d506aaa65fe1.html\">Bruno Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</a></p><p><b>topic</b>: <span title=\"Codes:\">Forspørgsel på seneste resultater</span></p><blockquote><p><b>payload</b></p><p><b>DateTimeExtension</b>: 2024-05-01 12:00:00+0200</p><p><b>IdentifierExtension</b>: urn:uuid:24d01288-ad36-4af2-96a8-fd1432dadee1</p><p><b>PractitionerExtension</b>: <a href=\"PractitionerRole-eda90bde-54f9-11ed-bdc3-0242ac120002.html\">PractitionerRole Sygeplejerske</a></p><p><b>ContactExtension</b>: ph: 38683868</p><p><b>content</b>: Til rette vedkommende. Vi ønsker information om de seneste undersøgelser udført på Bruno. På forhånd tak. Hilsen Michael, sygeplejerske.</p></blockquote></div>"
        },
        "identifier" : [
          {
            "value" : "urn:uuid:b2eb3d0e-5de5-4de9-b2a3-0ff321ad1c3a"
          }
        ],
        "status" : "unknown",
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-careCommunication-categoryCodes",
                "code" : "examination-results"
              }
            ]
          }
        ],
        "subject" : {
          "reference" : "Patient/733cef33-3626-422b-955d-d506aaa65fe1"
        },
        "topic" : {
          "text" : "Forspørgsel på seneste resultater"
        },
        "payload" : [
          {
            "extension" : [
              {
                "url" : "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-datetime-extension",
                "valueDateTime" : "2024-05-01T12:00:00+02:00"
              },
              {
                "url" : "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-identifier-extension",
                "valueIdentifier" : {
                  "value" : "urn:uuid:24d01288-ad36-4af2-96a8-fd1432dadee1",
                  "assigner" : {
                    "reference" : "Organization/b581c63c-181f-46f6-990d-b9942c576724"
                  }
                }
              },
              {
                "url" : "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-practitioner-extension",
                "valueReference" : {
                  "reference" : "PractitionerRole/eda90bde-54f9-11ed-bdc3-0242ac120002"
                }
              },
              {
                "url" : "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-contact-extension",
                "valueContactPoint" : {
                  "system" : "phone",
                  "value" : "38683868"
                }
              }
            ],
            "contentString" : "Til rette vedkommende. Vi ønsker information om de seneste undersøgelser udført på Bruno. På forhånd tak. Hilsen Michael, sygeplejerske."
          }
        ]
      }
    },
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/PractitionerRole/eda90bde-54f9-11ed-bdc3-0242ac120002",
      "resource" : {
        "resourceType" : "PractitionerRole",
        "id" : "eda90bde-54f9-11ed-bdc3-0242ac120002",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-practitionerrole"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_eda90bde-54f9-11ed-bdc3-0242ac120002\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole eda90bde-54f9-11ed-bdc3-0242ac120002</b></p><a name=\"eda90bde-54f9-11ed-bdc3-0242ac120002\"> </a><a name=\"hceda90bde-54f9-11ed-bdc3-0242ac120002\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/3.0.1/StructureDefinition-medcom-core-practitionerrole.html\">MedComCorePractitionerRole</a></p></div><p><b>practitioner</b>: <a href=\"Practitioner-58c811a5-4082-44eb-9d66-ccbb112d4973.html\">Practitioner Michael Burns </a></p><p><b>code</b>: <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-PractitionerRolesSKSadministrativ sygeplejerske}\">Sygeplejerske</span></p></div>"
        },
        "practitioner" : {
          "reference" : "Practitioner/58c811a5-4082-44eb-9d66-ccbb112d4973"
        },
        "code" : [
          {
            "coding" : [
              {
                "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-PractitionerRolesSKSadministrativ",
                "code" : "sygeplejerske"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/Practitioner/58c811a5-4082-44eb-9d66-ccbb112d4973",
      "resource" : {
        "resourceType" : "Practitioner",
        "id" : "58c811a5-4082-44eb-9d66-ccbb112d4973",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-practitioner"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_58c811a5-4082-44eb-9d66-ccbb112d4973\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner 58c811a5-4082-44eb-9d66-ccbb112d4973</b></p><a name=\"58c811a5-4082-44eb-9d66-ccbb112d4973\"> </a><a name=\"hc58c811a5-4082-44eb-9d66-ccbb112d4973\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/3.0.1/StructureDefinition-medcom-core-practitioner.html\">MedComCorePractitioner</a></p></div><p><b>name</b>: Michael Burns </p></div>"
        },
        "name" : [
          {
            "family" : "Burns",
            "given" : ["Michael"]
          }
        ]
      }
    },
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/Organization/487ac745-fd11-4879-9b59-c08c7d47260e",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "487ac745-fd11-4879-9b59-c08c7d47260e",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_487ac745-fd11-4879-9b59-c08c7d47260e\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization 487ac745-fd11-4879-9b59-c08c7d47260e</b></p><a name=\"487ac745-fd11-4879-9b59-c08c7d47260e\"> </a><a name=\"hc487ac745-fd11-4879-9b59-c08c7d47260e\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/4.0.2/StructureDefinition-medcom-messaging-organization.html\">MedComMessagingOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790001348120, <code>urn:oid:1.2.208.176.1.1</code>/953741000016009</p><p><b>name</b>: Plejecenter Herlev</p></div>"
        },
        "identifier" : [
          {
            "system" : "https://www.gs1.org/gln",
            "value" : "5790001348120"
          },
          {
            "system" : "urn:oid:1.2.208.176.1.1",
            "value" : "953741000016009"
          }
        ],
        "name" : "Plejecenter Herlev"
      }
    },
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/Organization/b581c63c-181f-46f6-990d-b9942c576724",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "b581c63c-181f-46f6-990d-b9942c576724",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_b581c63c-181f-46f6-990d-b9942c576724\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization b581c63c-181f-46f6-990d-b9942c576724</b></p><a name=\"b581c63c-181f-46f6-990d-b9942c576724\"> </a><a name=\"hcb581c63c-181f-46f6-990d-b9942c576724\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/4.0.2/StructureDefinition-medcom-messaging-organization.html\">MedComMessagingOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790000209354, <code>urn:oid:1.2.208.176.1.1</code>/265161000016000</p><p><b>name</b>: Hjerteafdelingen på Herlev og Gentofte hospital</p></div>"
        },
        "identifier" : [
          {
            "system" : "https://www.gs1.org/gln",
            "value" : "5790000209354"
          },
          {
            "system" : "urn:oid:1.2.208.176.1.1",
            "value" : "265161000016000"
          }
        ],
        "name" : "Hjerteafdelingen på Herlev og Gentofte hospital"
      }
    },
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/Provenance/4c284936-5454-4116-95fc-3c8eeeed2400",
      "resource" : {
        "resourceType" : "Provenance",
        "id" : "4c284936-5454-4116-95fc-3c8eeeed2400",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/carecommunication/StructureDefinition/medcom-careCommunication-provenance"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_4c284936-5454-4116-95fc-3c8eeeed2400\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance 4c284936-5454-4116-95fc-3c8eeeed2400</b></p><a name=\"4c284936-5454-4116-95fc-3c8eeeed2400\"> </a><a name=\"hc4c284936-5454-4116-95fc-3c8eeeed2400\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-careCommunication-provenance.html\">MedComCareCommunicationProvenance</a></p></div><p>Provenance for <a href=\"MessageHeader-42cb9200-f421-4d08-8391-7d51a2503cb4.html\">MessageHeader: event[x] = Care Communication Message (MedComMessagingEventCodes#care-communication-message); definition = http://medcomfhir.dk/ig/messagedefinitions/MessageDefinition/MedComCareCommunicationMessageDefinition|5.0</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>2024-05-01 12:00:00+0200</td></tr><tr><td>Recorded</td><td>2024-05-01 12:00:00+0200</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes new-message}\">A new message has been sent</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>who</b></td></tr><tr><td><a href=\"Organization-b581c63c-181f-46f6-990d-b9942c576724.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></td></tr></table></div>"
        },
        "target" : [
          {
            "reference" : "MessageHeader/42cb9200-f421-4d08-8391-7d51a2503cb4"
          }
        ],
        "occurredDateTime" : "2024-05-01T12:00:00+02:00",
        "recorded" : "2024-05-01T12:00:00+02:00",
        "activity" : {
          "coding" : [
            {
              "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes",
              "code" : "new-message"
            }
          ]
        },
        "agent" : [
          {
            "who" : {
              "reference" : "Organization/b581c63c-181f-46f6-990d-b9942c576724"
            }
          }
        ],
        "entity" : [
          {
            "role" : "source",
            "what" : {
              "identifier" : {
                "value" : "urn:uuid:24d01288-ad36-4af2-96a8-fd1432dadee1"
              }
            }
          }
        ]
      }
    }
  ]
}

```
