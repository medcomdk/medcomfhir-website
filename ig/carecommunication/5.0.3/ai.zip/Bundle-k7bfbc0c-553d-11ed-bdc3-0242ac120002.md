# Reply CareCommunication message. Reply to OIOXML Message - DK MedCom Carecommunication v5.0.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Reply CareCommunication message. Reply to OIOXML Message**

## Example Bundle: Reply CareCommunication message. Reply to OIOXML Message



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "k7bfbc0c-553d-11ed-bdc3-0242ac120002",
  "meta" : {
    "profile" : [
      "http://medcomfhir.dk/ig/carecommunication/StructureDefinition/medcom-careCommunication-message"
    ]
  },
  "type" : "message",
  "timestamp" : "2024-05-07T18:00:00+02:00",
  "entry" : [
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/MessageHeader/3076d9b0-5521-11ed-bdc3-0242ac120002",
      "resource" : {
        "resourceType" : "MessageHeader",
        "id" : "3076d9b0-5521-11ed-bdc3-0242ac120002",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/carecommunication/StructureDefinition/medcom-careCommunication-messageHeader"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_3076d9b0-5521-11ed-bdc3-0242ac120002\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader 3076d9b0-5521-11ed-bdc3-0242ac120002</b></p><a name=\"3076d9b0-5521-11ed-bdc3-0242ac120002\"> </a><a name=\"hc3076d9b0-5521-11ed-bdc3-0242ac120002\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-careCommunication-messageHeader.html\">MedComCareCommunicationMessageHeader</a></p></div><p><b>event</b>: <a href=\"http://medcomfhir.dk/ig/terminology/2.0.1/CodeSystem-medcom-messaging-eventCodes.html#medcom-messaging-eventCodes-care-communication-message\">MedComMessagingEventCodes: care-communication-message</a> (Care Communication Message)</p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Endpoint</b></td><td><b>Receiver</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><a href=\"https://sor2.sum.dsdn.dk/#id=953741000016009\">https://sor2.sum.dsdn.dk/#id=953741000016009</a></td><td><a href=\"Organization-ae899cbd-933b-4581-9a16-bd2da73f06a0.html\">Organization Plejecenter Herlev</a></td></tr></table><p><b>sender</b>: <a href=\"Organization-e17d03b8-e7fd-4654-bc9c-cb2eb5dda71f.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://sor2.sum.dsdn.dk/#id=265161000016000\">https://sor2.sum.dsdn.dk/#id=265161000016000</a></td></tr></table><p><b>focus</b>: <a href=\"Communication-f54efd18-5520-11ed-bdc3-0242ac120002.html\">Communication: identifier = urn:uuid:59aac95e-ca57-4b04-b075-9880b7e6441c; status = unknown; category = Forløbskoordinering</a></p><p><b>definition</b>: <a href=\"http://medcomfhir.dk/ig/messagedefinitions/1.0.0/MessageDefinition-MedComCareCommunicationMessageDefinitionV5.0.html\">http://medcomfhir.dk/ig/messagedefinitions/MessageDefinition/MedComCareCommunicationMessageDefinition|5.0</a></p></div>"
        },
        "eventCoding" : {
          "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-eventCodes",
          "code" : "care-communication-message"
        },
        "destination" : [
          {
            "extension" : [
              {
                "url" : "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-destinationUseExtension",
                "valueCoding" : {
                  "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-destinationUse",
                  "code" : "primary"
                }
              }
            ],
            "endpoint" : "https://sor2.sum.dsdn.dk/#id=953741000016009",
            "receiver" : {
              "reference" : "Organization/ae899cbd-933b-4581-9a16-bd2da73f06a0"
            }
          }
        ],
        "sender" : {
          "reference" : "Organization/e17d03b8-e7fd-4654-bc9c-cb2eb5dda71f"
        },
        "source" : {
          "endpoint" : "https://sor2.sum.dsdn.dk/#id=265161000016000"
        },
        "focus" : [
          {
            "reference" : "Communication/f54efd18-5520-11ed-bdc3-0242ac120002"
          }
        ],
        "definition" : "http://medcomfhir.dk/ig/messagedefinitions/MessageDefinition/MedComCareCommunicationMessageDefinition|5.0"
      }
    },
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/Patient/23ebfcd8-e4f2-4ce8-908b-aa7cfb9ffef5",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "23ebfcd8-e4f2-4ce8-908b-aa7cfb9ffef5",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_23ebfcd8-e4f2-4ce8-908b-aa7cfb9ffef5\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient 23ebfcd8-e4f2-4ce8-908b-aa7cfb9ffef5</b></p><a name=\"23ebfcd8-e4f2-4ce8-908b-aa7cfb9ffef5\"> </a><a name=\"hc23ebfcd8-e4f2-4ce8-908b-aa7cfb9ffef5\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/3.0.1/StructureDefinition-medcom-core-patient.html\">MedComCorePatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</p><hr/></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:1.2.208.176.1.2",
            "value" : "2509479989"
          }
        ],
        "name" : [
          {
            "use" : "official",
            "family" : "Elmer"
          }
        ]
      }
    },
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/Communication/f54efd18-5520-11ed-bdc3-0242ac120002",
      "resource" : {
        "resourceType" : "Communication",
        "id" : "f54efd18-5520-11ed-bdc3-0242ac120002",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/carecommunication/StructureDefinition/medcom-careCommunication-communication"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Communication_f54efd18-5520-11ed-bdc3-0242ac120002\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Communication f54efd18-5520-11ed-bdc3-0242ac120002</b></p><a name=\"f54efd18-5520-11ed-bdc3-0242ac120002\"> </a><a name=\"hcf54efd18-5520-11ed-bdc3-0242ac120002\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-careCommunication-communication.html\">MedComCareCommunication</a></p></div><p><b>identifier</b>: urn:uuid:59aac95e-ca57-4b04-b075-9880b7e6441c</p><p><b>status</b>: Unknown</p><p><b>category</b>: <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-careCommunication-categoryCodes carecoordination}\">Forløbskoordinering</span></p><p><b>subject</b>: <a href=\"Patient-23ebfcd8-e4f2-4ce8-908b-aa7cfb9ffef5.html\">Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</a></p><p><b>encounter</b>: <a href=\"Encounter-303b2782-e2bf-4780-a8a5-c4b02b0e1c66.html\">Encounter: status = in-progress; class = inpatient encounter (ActCode#IMP)</a></p><blockquote><p><b>payload</b></p><p><b>DateTimeExtension</b>: 2024-05-07 18:00:00+0200</p><p><b>IdentifierExtension</b>: urn:uuid:1813b23d-195e-4b28-8221-24247035bf08</p><p><b>PractitionerExtension</b>: <a href=\"PractitionerRole-8dc790ba-8d93-4585-b91c-af8225b0796d.html\">PractitionerRole Sygeplejerske</a></p><p><b>ContactExtension</b>: ph: 38683868</p><p><b>content</b>: We have a question regarding the referal...</p></blockquote></div>"
        },
        "identifier" : [
          {
            "value" : "urn:uuid:59aac95e-ca57-4b04-b075-9880b7e6441c"
          }
        ],
        "status" : "unknown",
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-careCommunication-categoryCodes",
                "code" : "carecoordination"
              }
            ]
          }
        ],
        "subject" : {
          "reference" : "Patient/23ebfcd8-e4f2-4ce8-908b-aa7cfb9ffef5"
        },
        "encounter" : {
          "reference" : "Encounter/303b2782-e2bf-4780-a8a5-c4b02b0e1c66"
        },
        "payload" : [
          {
            "extension" : [
              {
                "url" : "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-datetime-extension",
                "valueDateTime" : "2024-05-07T18:00:00+02:00"
              },
              {
                "url" : "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-identifier-extension",
                "valueIdentifier" : {
                  "value" : "urn:uuid:1813b23d-195e-4b28-8221-24247035bf08",
                  "assigner" : {
                    "reference" : "Organization/e17d03b8-e7fd-4654-bc9c-cb2eb5dda71f"
                  }
                }
              },
              {
                "url" : "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-practitioner-extension",
                "valueReference" : {
                  "reference" : "PractitionerRole/8dc790ba-8d93-4585-b91c-af8225b0796d"
                }
              },
              {
                "url" : "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-contact-extension",
                "valueContactPoint" : {
                  "system" : "phone",
                  "value" : "38683868"
                }
              }
            ],
            "contentString" : "We have a question regarding the referal..."
          }
        ]
      }
    },
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/PractitionerRole/8dc790ba-8d93-4585-b91c-af8225b0796d",
      "resource" : {
        "resourceType" : "PractitionerRole",
        "id" : "8dc790ba-8d93-4585-b91c-af8225b0796d",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-practitionerrole"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_8dc790ba-8d93-4585-b91c-af8225b0796d\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole 8dc790ba-8d93-4585-b91c-af8225b0796d</b></p><a name=\"8dc790ba-8d93-4585-b91c-af8225b0796d\"> </a><a name=\"hc8dc790ba-8d93-4585-b91c-af8225b0796d\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/3.0.1/StructureDefinition-medcom-core-practitionerrole.html\">MedComCorePractitionerRole</a></p></div><p><b>practitioner</b>: <a href=\"Practitioner-8659596f-6ef4-421c-9ecd-94b65e4d5ff8.html\">Practitioner Michael Burns </a></p><p><b>code</b>: <span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-PractitionerRolesSKSadministrativ sygeplejerske}\">Sygeplejerske</span></p></div>"
        },
        "practitioner" : {
          "reference" : "Practitioner/8659596f-6ef4-421c-9ecd-94b65e4d5ff8"
        },
        "code" : [
          {
            "coding" : [
              {
                "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-core-PractitionerRolesSKSadministrativ",
                "code" : "sygeplejerske"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/Practitioner/8659596f-6ef4-421c-9ecd-94b65e4d5ff8",
      "resource" : {
        "resourceType" : "Practitioner",
        "id" : "8659596f-6ef4-421c-9ecd-94b65e4d5ff8",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-practitioner"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_8659596f-6ef4-421c-9ecd-94b65e4d5ff8\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner 8659596f-6ef4-421c-9ecd-94b65e4d5ff8</b></p><a name=\"8659596f-6ef4-421c-9ecd-94b65e4d5ff8\"> </a><a name=\"hc8659596f-6ef4-421c-9ecd-94b65e4d5ff8\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/3.0.1/StructureDefinition-medcom-core-practitioner.html\">MedComCorePractitioner</a></p></div><p><b>name</b>: Michael Burns </p></div>"
        },
        "name" : [
          {
            "family" : "Burns",
            "given" : ["Michael"]
          }
        ]
      }
    },
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/Encounter/303b2782-e2bf-4780-a8a5-c4b02b0e1c66",
      "resource" : {
        "resourceType" : "Encounter",
        "id" : "303b2782-e2bf-4780-a8a5-c4b02b0e1c66",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-encounter"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_303b2782-e2bf-4780-a8a5-c4b02b0e1c66\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter 303b2782-e2bf-4780-a8a5-c4b02b0e1c66</b></p><a name=\"303b2782-e2bf-4780-a8a5-c4b02b0e1c66\"> </a><a name=\"hc303b2782-e2bf-4780-a8a5-c4b02b0e1c66\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/3.0.1/StructureDefinition-medcom-core-encounter.html\">MedComCoreEncounter</a></p></div><p><b>status</b>: In Progress</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.1.0/CodeSystem-v3-ActCode.html#v3-ActCode-IMP\">ActCode: IMP</a> (inpatient encounter)</p><p><b>subject</b>: <a href=\"Patient-23ebfcd8-e4f2-4ce8-908b-aa7cfb9ffef5.html\">Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#2509479989)</a></p><p><b>episodeOfCare</b>: Identifier: <code>https://sor2.sum.dsdn.dk/#id=265161000016000</code>/fc60e762-b13b-5773-865e-67f3907bdcc7</p></div>"
        },
        "status" : "in-progress",
        "class" : {
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
          "code" : "IMP"
        },
        "subject" : {
          "reference" : "Patient/23ebfcd8-e4f2-4ce8-908b-aa7cfb9ffef5"
        },
        "episodeOfCare" : [
          {
            "identifier" : {
              "system" : "https://sor2.sum.dsdn.dk/#id=265161000016000",
              "value" : "fc60e762-b13b-5773-865e-67f3907bdcc7"
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/Organization/ae899cbd-933b-4581-9a16-bd2da73f06a0",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "ae899cbd-933b-4581-9a16-bd2da73f06a0",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_ae899cbd-933b-4581-9a16-bd2da73f06a0\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization ae899cbd-933b-4581-9a16-bd2da73f06a0</b></p><a name=\"ae899cbd-933b-4581-9a16-bd2da73f06a0\"> </a><a name=\"hcae899cbd-933b-4581-9a16-bd2da73f06a0\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/4.0.2/StructureDefinition-medcom-messaging-organization.html\">MedComMessagingOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790001348120, <code>urn:oid:1.2.208.176.1.1</code>/953741000016009</p><p><b>name</b>: Plejecenter Herlev</p></div>"
        },
        "identifier" : [
          {
            "system" : "https://www.gs1.org/gln",
            "value" : "5790001348120"
          },
          {
            "system" : "urn:oid:1.2.208.176.1.1",
            "value" : "953741000016009"
          }
        ],
        "name" : "Plejecenter Herlev"
      }
    },
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/Organization/e17d03b8-e7fd-4654-bc9c-cb2eb5dda71f",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "e17d03b8-e7fd-4654-bc9c-cb2eb5dda71f",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_e17d03b8-e7fd-4654-bc9c-cb2eb5dda71f\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization e17d03b8-e7fd-4654-bc9c-cb2eb5dda71f</b></p><a name=\"e17d03b8-e7fd-4654-bc9c-cb2eb5dda71f\"> </a><a name=\"hce17d03b8-e7fd-4654-bc9c-cb2eb5dda71f\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/4.0.2/StructureDefinition-medcom-messaging-organization.html\">MedComMessagingOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790000209354, <code>urn:oid:1.2.208.176.1.1</code>/265161000016000</p><p><b>name</b>: Hjerteafdelingen på Herlev og Gentofte hospital</p></div>"
        },
        "identifier" : [
          {
            "system" : "https://www.gs1.org/gln",
            "value" : "5790000209354"
          },
          {
            "system" : "urn:oid:1.2.208.176.1.1",
            "value" : "265161000016000"
          }
        ],
        "name" : "Hjerteafdelingen på Herlev og Gentofte hospital"
      }
    },
    {
      "fullUrl" : "https://medcomfhir.dk/ig/carecommunication/Provenance/6de0806d-7050-4db8-8003-0c72aee52948",
      "resource" : {
        "resourceType" : "Provenance",
        "id" : "6de0806d-7050-4db8-8003-0c72aee52948",
        "meta" : {
          "profile" : [
            "http://medcomfhir.dk/ig/carecommunication/StructureDefinition/medcom-careCommunication-provenance"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_6de0806d-7050-4db8-8003-0c72aee52948\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance 6de0806d-7050-4db8-8003-0c72aee52948</b></p><a name=\"6de0806d-7050-4db8-8003-0c72aee52948\"> </a><a name=\"hc6de0806d-7050-4db8-8003-0c72aee52948\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-careCommunication-provenance.html\">MedComCareCommunicationProvenance</a></p></div><p>Provenance for <a href=\"MessageHeader-3076d9b0-5521-11ed-bdc3-0242ac120002.html\">MessageHeader: event[x] = Care Communication Message (MedComMessagingEventCodes#care-communication-message); definition = http://medcomfhir.dk/ig/messagedefinitions/MessageDefinition/MedComCareCommunicationMessageDefinition|5.0</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>2024-05-07 18:00:00+0200</td></tr><tr><td>Recorded</td><td>2024-05-07 18:00:00+0200</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes reply-message}\">A message has been replied to</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>who</b></td></tr><tr><td><a href=\"Organization-e17d03b8-e7fd-4654-bc9c-cb2eb5dda71f.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></td></tr></table></div>"
        },
        "target" : [
          {
            "reference" : "MessageHeader/3076d9b0-5521-11ed-bdc3-0242ac120002"
          }
        ],
        "occurredDateTime" : "2024-05-07T18:00:00+02:00",
        "recorded" : "2024-05-07T18:00:00+02:00",
        "activity" : {
          "coding" : [
            {
              "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes",
              "code" : "reply-message"
            }
          ]
        },
        "agent" : [
          {
            "who" : {
              "reference" : "Organization/e17d03b8-e7fd-4654-bc9c-cb2eb5dda71f"
            }
          }
        ],
        "entity" : [
          {
            "role" : "source",
            "what" : {
              "identifier" : {
                "value" : "urn:uuid:8521000b-ce04-4c18-b9b1-04dcbdf8e112"
              }
            }
          },
          {
            "role" : "revision",
            "what" : {
              "identifier" : {
                "value" : "B300720181623#5790000121526"
              }
            }
          }
        ]
      }
    }
  ]
}

```
