# Example of a reciever organization with a SOR and an EAN identifier. - DK MedCom Carecommunication v5.0.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example of a reciever organization with a SOR and an EAN identifier.**

## Example Organization: Example of a reciever organization with a SOR and an EAN identifier.

Profile: [MedComMessagingOrganization](http://medcomfhir.dk/ig/messaging/4.0.2/StructureDefinition-medcom-messaging-organization.html)

**identifier**: `https://www.gs1.org/gln`/5790001348120, `urn:oid:1.2.208.176.1.1`/1042981000016003



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "f98ed410-54fe-11ed-bdc3-0242ac120002",
  "meta" : {
    "profile" : [
      "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"
    ]
  },
  "identifier" : [
    {
      "system" : "https://www.gs1.org/gln",
      "value" : "5790001348120"
    },
    {
      "system" : "urn:oid:1.2.208.176.1.1",
      "value" : "1042981000016003"
    }
  ]
}

```
